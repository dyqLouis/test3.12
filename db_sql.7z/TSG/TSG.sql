conn sys/sys123@orcl as sysdba ;

declare num number;   
begin  
 select count(1) into num from all_users where username='TSG';  
 if num>0   
  then execute immediate 'drop user TSG cascade';   
 end if;   
end;   
/  

grant connect,resource to TSG identified by a123456; 
alter user TSG default tablespace YCO_DATA;
connect TSG/a123456@orcl ;

create table T_TSG_CLASS
(
  ID   NUMBER(19) not null,
  NAME VARCHAR2(60 CHAR)
)
tablespace YCO_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table T_TSG_CLASS
  add primary key (ID)
  using index 
  tablespace YCO_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
grant select, insert, update, delete on T_TSG_CLASS to YCODATA_STUDY;

prompt Creating T_TSG_GRADE...
create table T_TSG_GRADE
(
  ID    NUMBER(19) not null,
  SCORE NUMBER(5,2),
  SCORE_RANK  CHAR(2)
)
tablespace YCO_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table T_TSG_GRADE
  add primary key (ID)
  using index 
  tablespace YCO_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
grant select, insert, update, delete on T_TSG_GRADE to YCODATA_STUDY;

prompt Creating T_TSG_STUDENT...
create table T_TSG_STUDENT
(
  ID       NUMBER(19) not null,
  NAME     VARCHAR2(60 CHAR),
  CLASS_ID NUMBER(19)
)
tablespace YCO_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table T_TSG_STUDENT
  add primary key (ID)
  using index 
  tablespace YCO_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
grant select, insert, update, delete on T_TSG_STUDENT to YCODATA_STUDY;

create table T_TSG_STUDENT_SCORE
(
  ID            NUMBER(19) not null,
  STUDENT_ID    NUMBER(19),
  TERM          NUMBER,
  SUBJECT       VARCHAR2(160 CHAR),
  SCORE         NUMBER(5,2),
  MAKE_UP       CHAR(2),
  SUBJECT_TIMES NUMBER
)
tablespace YCO_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
comment on column T_TSG_STUDENT_SCORE.TERM
  is '1:一年级上学期;2:一年级下学期;3:二年级上学期;4:二年级下学期.....';
comment on column T_TSG_STUDENT_SCORE.MAKE_UP
  is 'Y:补考;N:非补考';
comment on column T_TSG_STUDENT_SCORE.SUBJECT_TIMES
  is 'N:第N次考试;N=1,2,3,4,5,....';
alter table T_TSG_STUDENT_SCORE
  add primary key (ID)
  using index 
  tablespace YCO_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
grant select, insert, update, delete on T_TSG_STUDENT_SCORE to YCODATA_STUDY;

prompt Creating T_TSG_TEACHER...
create table T_TSG_TEACHER
(
  ID   NUMBER(19) not null,
  NAME VARCHAR2(60 CHAR)
)
tablespace YCO_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table T_TSG_TEACHER
  add primary key (ID)
  using index 
  tablespace YCO_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
grant select, insert, update, delete on T_TSG_TEACHER to YCODATA_STUDY;

prompt Creating T_TSG_TEACHER_CLASS...
create table T_TSG_TEACHER_CLASS
(
  ID         NUMBER(19) not null,
  TEACHER_ID NUMBER(19),
  CLASS_ID   NUMBER(19)
)
tablespace YCO_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table T_TSG_TEACHER_CLASS
  add primary key (ID)
  using index 
  tablespace YCO_IDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

create sequence SEQ_TSG_TEACHER start with 3000 increment by 1;  
create sequence SEQ_TSG_CLASS start with 200 increment by 1;  
create sequence SEQ_TSG_TEACHER_CLASS start with 4000 increment by 1;  
create sequence SEQ_TSG_STUDENT start with 10000 increment by 1;  
---create sequence SEQ_TSG_STUDENT_SCORE start with 6000 increment by 1; 
create sequence SEQ_TSG_GRADE start with 5000 increment by 1;  

---T_TSG_TEACHER第一条记录id=3001
insert into T_TSG_TEACHER (ID, NAME)values (SEQ_TSG_TEACHER.nextval, '英语老师');
insert into T_TSG_TEACHER (ID, NAME)values (SEQ_TSG_TEACHER.nextval, '数学老师');
insert into T_TSG_TEACHER (ID, NAME)values (SEQ_TSG_TEACHER.nextval, '体育老师');
insert into T_TSG_TEACHER (ID, NAME)values (SEQ_TSG_TEACHER.nextval, '语文老师');
commit;
---T_TSG_CLASS第一条记录id=201
insert into T_TSG_CLASS (ID, NAME)values (SEQ_TSG_CLASS.nextval, '201班');
insert into T_TSG_CLASS (ID, NAME)values (SEQ_TSG_CLASS.nextval, '202班');
insert into T_TSG_CLASS (ID, NAME)values (SEQ_TSG_CLASS.nextval, '203班');
commit;
---T_TSG_TEACHER_CLASS第一条记录id=4001
insert into T_TSG_TEACHER_CLASS (ID, TEACHER_ID, CLASS_ID)values (SEQ_TSG_TEACHER_CLASS.nextval, 3001, 201);
insert into T_TSG_TEACHER_CLASS (ID, TEACHER_ID, CLASS_ID)values (SEQ_TSG_TEACHER_CLASS.nextval, 3001, 202);
insert into T_TSG_TEACHER_CLASS (ID, TEACHER_ID, CLASS_ID)values (SEQ_TSG_TEACHER_CLASS.nextval, 3002, 201);
insert into T_TSG_TEACHER_CLASS (ID, TEACHER_ID, CLASS_ID)values (SEQ_TSG_TEACHER_CLASS.nextval, 3002, 202);
insert into T_TSG_TEACHER_CLASS (ID, TEACHER_ID, CLASS_ID)values (SEQ_TSG_TEACHER_CLASS.nextval, 3003, 201);
insert into T_TSG_TEACHER_CLASS (ID, TEACHER_ID, CLASS_ID)values (SEQ_TSG_TEACHER_CLASS.nextval, 3003, 202);
insert into T_TSG_TEACHER_CLASS (ID, TEACHER_ID, CLASS_ID)values (SEQ_TSG_TEACHER_CLASS.nextval, 3004, 201);
insert into T_TSG_TEACHER_CLASS (ID, TEACHER_ID, CLASS_ID)values (SEQ_TSG_TEACHER_CLASS.nextval, 3004, 202);
insert into T_TSG_TEACHER_CLASS (ID, TEACHER_ID, CLASS_ID)values (SEQ_TSG_TEACHER_CLASS.nextval, 3001, 203);
insert into T_TSG_TEACHER_CLASS (ID, TEACHER_ID, CLASS_ID)values (SEQ_TSG_TEACHER_CLASS.nextval, 3002, 203);
insert into T_TSG_TEACHER_CLASS (ID, TEACHER_ID, CLASS_ID)values (SEQ_TSG_TEACHER_CLASS.nextval, 3003, 203);
insert into T_TSG_TEACHER_CLASS (ID, TEACHER_ID, CLASS_ID)values (SEQ_TSG_TEACHER_CLASS.nextval, 3004, 203);
commit;

---T_TSG_STUDENT第一条记录id=10001
insert into T_TSG_STUDENT (ID, NAME, CLASS_ID)values (SEQ_TSG_STUDENT.nextval, '张三', 201);
insert into T_TSG_STUDENT (ID, NAME, CLASS_ID)values (SEQ_TSG_STUDENT.nextval, '李四', 201);
insert into T_TSG_STUDENT (ID, NAME, CLASS_ID)values (SEQ_TSG_STUDENT.nextval, '王五', 202);
insert into T_TSG_STUDENT (ID, NAME, CLASS_ID)values (SEQ_TSG_STUDENT.nextval, '赵六', 202);
insert into T_TSG_STUDENT (ID, NAME, CLASS_ID)values (SEQ_TSG_STUDENT.nextval, '陈七', 202);
insert into T_TSG_STUDENT (ID, NAME, CLASS_ID)values (SEQ_TSG_STUDENT.nextval, 'dyq6', 203);
commit;

----学生成绩表的插入触发器:
create sequence SEQ_TSG_STUDENT_SCORE start with 6001 increment by 1;

create or replace trigger TRIG_TSG_STUDENT_SCORE
      before insert on T_TSG_STUDENT_SCORE
     for each row
      begin
      ---第一次使用这个是从6001开始不是从6002
      select SEQ_TSG_STUDENT_SCORE.nextval into:new.ID from dual; 
     end;

insert into T_TSG_STUDENT_SCORE(STUDENT_ID, TERM, SUBJECT, SCORE, MAKE_UP, SUBJECT_TIMES)
values(10001, 1, '语文', 90, 'N ', 1);
insert into T_TSG_STUDENT_SCORE(STUDENT_ID, TERM, SUBJECT, SCORE, MAKE_UP, SUBJECT_TIMES)
values(10001, 1, '数学', 85, 'N ', 1);
insert into T_TSG_STUDENT_SCORE(STUDENT_ID, TERM, SUBJECT, SCORE, MAKE_UP, SUBJECT_TIMES)
values(10001, 1, '英语', 85, 'N ', 1);
insert into T_TSG_STUDENT_SCORE(STUDENT_ID, TERM, SUBJECT, SCORE, MAKE_UP, SUBJECT_TIMES)
values(10001, 1, '体育', null, 'N ', 1);
insert into T_TSG_STUDENT_SCORE(STUDENT_ID, TERM, SUBJECT, SCORE, MAKE_UP, SUBJECT_TIMES)
values(10002, 1, '语文', null, 'N ', 1);
insert into T_TSG_STUDENT_SCORE(STUDENT_ID, TERM, SUBJECT, SCORE, MAKE_UP, SUBJECT_TIMES)
values(10002, 1, '数学', 75, 'N ', 1);
insert into T_TSG_STUDENT_SCORE(STUDENT_ID, TERM, SUBJECT, SCORE, MAKE_UP, SUBJECT_TIMES)
values(10002, 1, '英语', 45, 'N ', 1);
insert into T_TSG_STUDENT_SCORE(STUDENT_ID, TERM, SUBJECT, SCORE, MAKE_UP, SUBJECT_TIMES)
values(10002, 1, '体育', 56, 'N ', 1);
insert into T_TSG_STUDENT_SCORE(STUDENT_ID, TERM, SUBJECT, SCORE, MAKE_UP, SUBJECT_TIMES)
values(10003, 1, '语文', 86, 'N ', 1);
insert into T_TSG_STUDENT_SCORE(STUDENT_ID, TERM, SUBJECT, SCORE, MAKE_UP, SUBJECT_TIMES)
values(10003, 1, '数学', 0, 'N ', 1);
insert into T_TSG_STUDENT_SCORE(STUDENT_ID, TERM, SUBJECT, SCORE, MAKE_UP, SUBJECT_TIMES)
values(10003, 1, '英语', 67, 'N ', 1);
insert into T_TSG_STUDENT_SCORE(STUDENT_ID, TERM, SUBJECT, SCORE, MAKE_UP, SUBJECT_TIMES)
values(10003, 1, '体育', 60, 'N ', 1);
insert into T_TSG_STUDENT_SCORE(STUDENT_ID, TERM, SUBJECT, SCORE, MAKE_UP, SUBJECT_TIMES)
values(10004, 1, '语文', 77, 'N ', 1);
insert into T_TSG_STUDENT_SCORE(STUDENT_ID, TERM, SUBJECT, SCORE, MAKE_UP, SUBJECT_TIMES)
values(10004, 1, '数学', 75, 'N ', 1);
insert into T_TSG_STUDENT_SCORE(STUDENT_ID, TERM, SUBJECT, SCORE, MAKE_UP, SUBJECT_TIMES)
values(10004, 1, '英语', 95, 'N ', 1);
insert into T_TSG_STUDENT_SCORE(STUDENT_ID, TERM, SUBJECT, SCORE, MAKE_UP, SUBJECT_TIMES)
values( 10004, 1, '体育', 95, 'N ', 1);
insert into T_TSG_STUDENT_SCORE(STUDENT_ID, TERM, SUBJECT, SCORE, MAKE_UP, SUBJECT_TIMES)
values( 10005, 1, '语文', 85, 'N ', 1);
insert into T_TSG_STUDENT_SCORE(STUDENT_ID, TERM, SUBJECT, SCORE, MAKE_UP, SUBJECT_TIMES)
values(10005, 1, '数学', 75, 'N ', 1);
insert into T_TSG_STUDENT_SCORE(STUDENT_ID, TERM, SUBJECT, SCORE, MAKE_UP, SUBJECT_TIMES)
values( 10005, 1, '英语', 45, 'N ', 1);
insert into T_TSG_STUDENT_SCORE(STUDENT_ID, TERM, SUBJECT, SCORE, MAKE_UP, SUBJECT_TIMES)
values(10005, 1, '体育', 80, 'N ', 1);
insert into T_TSG_STUDENT_SCORE(STUDENT_ID, TERM, SUBJECT, SCORE, MAKE_UP, SUBJECT_TIMES)
values( 10006, 1, '体育', 75, 'N ', 1);
insert into T_TSG_STUDENT_SCORE(STUDENT_ID, TERM, SUBJECT, SCORE, MAKE_UP, SUBJECT_TIMES)
values(10003, 1, '语文', 86, 'N ', 2);
insert into T_TSG_STUDENT_SCORE(STUDENT_ID, TERM, SUBJECT, SCORE, MAKE_UP, SUBJECT_TIMES)
values(10003, 1, '数学', 90, 'N ', 2);
insert into T_TSG_STUDENT_SCORE(STUDENT_ID, TERM, SUBJECT, SCORE, MAKE_UP, SUBJECT_TIMES)
values(10003, 1, '英语', 87, 'N ', 2);
insert into T_TSG_STUDENT_SCORE(STUDENT_ID, TERM, SUBJECT, SCORE, MAKE_UP, SUBJECT_TIMES)
values(10003, 1, '体育', 60, 'N ', 2);
insert into T_TSG_STUDENT_SCORE(STUDENT_ID, TERM, SUBJECT, SCORE, MAKE_UP, SUBJECT_TIMES)
values(10004, 1, '语文', 77, 'N ', 2);
insert into T_TSG_STUDENT_SCORE(STUDENT_ID, TERM, SUBJECT, SCORE, MAKE_UP, SUBJECT_TIMES)
values(10004, 1, '数学', 75, 'N ', 2);
insert into T_TSG_STUDENT_SCORE(STUDENT_ID, TERM, SUBJECT, SCORE, MAKE_UP, SUBJECT_TIMES)
values(10004, 1, '英语', 96, 'N ', 2);
insert into T_TSG_STUDENT_SCORE(STUDENT_ID, TERM, SUBJECT, SCORE, MAKE_UP, SUBJECT_TIMES)
values(10004, 1, '体育', 95, 'N ', 2);
insert into T_TSG_STUDENT_SCORE(STUDENT_ID, TERM, SUBJECT, SCORE, MAKE_UP, SUBJECT_TIMES)
values(10005, 1, '语文', 85, 'N ', 2);
insert into T_TSG_STUDENT_SCORE(STUDENT_ID, TERM, SUBJECT, SCORE, MAKE_UP, SUBJECT_TIMES)
values(10005, 1, '数学', 75, 'N ', 2);
insert into T_TSG_STUDENT_SCORE(STUDENT_ID, TERM, SUBJECT, SCORE, MAKE_UP, SUBJECT_TIMES)
values(10005, 1, '英语', 75, 'N ', 2);
insert into T_TSG_STUDENT_SCORE(STUDENT_ID, TERM, SUBJECT, SCORE, MAKE_UP, SUBJECT_TIMES)
values(10005, 1, '体育', 80, 'N ', 2);
insert into T_TSG_STUDENT_SCORE(STUDENT_ID, TERM, SUBJECT, SCORE, MAKE_UP, SUBJECT_TIMES)
values(10001, 1, '语文', 85, 'N ', 2);
insert into T_TSG_STUDENT_SCORE(STUDENT_ID, TERM, SUBJECT, SCORE, MAKE_UP, SUBJECT_TIMES)
values(10001, 1, '数学', 75, 'N ', 2);
insert into T_TSG_STUDENT_SCORE(STUDENT_ID, TERM, SUBJECT, SCORE, MAKE_UP, SUBJECT_TIMES)
values(10001, 1, '英语', null, 'N ', 2);
insert into T_TSG_STUDENT_SCORE(STUDENT_ID, TERM, SUBJECT, SCORE, MAKE_UP, SUBJECT_TIMES)
values(10001, 1, '体育', 80, 'N ', 2);


insert into T_TSG_GRADE (ID, SCORE, SCORE_RANK)values (SEQ_TSG_GRADE.nextval, 90, 'A ');
insert into T_TSG_GRADE (ID, SCORE, SCORE_RANK)values (SEQ_TSG_GRADE.nextval, 80, 'B ');
insert into T_TSG_GRADE (ID, SCORE, SCORE_RANK)values (SEQ_TSG_GRADE.nextval, 70, 'C ');
insert into T_TSG_GRADE (ID, SCORE, SCORE_RANK)values (SEQ_TSG_GRADE.nextval, 60, 'D ');
insert into T_TSG_GRADE (ID, SCORE, SCORE_RANK)values (SEQ_TSG_GRADE.nextval, 59, 'E ');
commit;

select * from t_tsg_teacher_class t;
select * from t_tsg_teacher t;
select * from t_tsg_student_score t;
select * from t_tsg_student t;
select * from t_tsg_grade t;
select * from t_tsg_class t;
