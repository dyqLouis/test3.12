package bean;

public class uesrbean {
	
	private int uesrID;
	private String loginname,loginPass;
	public int getUesrID() {
		return uesrID;
	}
	public void setUesrID(int uesrID) {
		this.uesrID = uesrID;
	}
	public String getLoginname() {
		return loginname;
	}
	public void setLoginname(String loginname) {
		this.loginname = loginname;
	}
	public String getLoginPass() {
		return loginPass;
	}
	public void setLoginPass(String loginPass) {
		this.loginPass = loginPass;
	}
	

}
