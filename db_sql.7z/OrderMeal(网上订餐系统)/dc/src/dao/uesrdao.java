package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import bean.uesrbean;

public class uesrdao {
	
	private Connection conn;
	private ResultSet rs;
	private PreparedStatement ps;

public void clearUp(){
		
		try {
			if(rs != null)rs.close();
			if(ps != null)ps.close();
			if(conn != null)conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public uesrbean check(uesrbean ub ){
		uesrbean u=null;
		String sql="select * from userInfo where loginname=? and loginpass=?";
		conn=new DB().getconn();
		try {
			ps=conn.prepareStatement(sql);
			ps.setString(1,ub.getLoginname());
			ps.setString(2,ub.getLoginPass());
			rs=ps.executeQuery();
			while(rs.next()){
				u=new uesrbean();
				u.setUesrID(rs.getInt(1));
				u.setLoginname(rs.getString(2));
				u.setLoginPass(rs.getString(3));
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			
			this.clearUp();
		}
		return u;
	}
	
	public static void main(String[] args) {
		uesrbean u=new uesrbean();
		u.setLoginname("d");
		u.setLoginPass("j");
		uesrbean ub=new uesrdao().check(u);
		System.out.println(ub);
		
	}}
