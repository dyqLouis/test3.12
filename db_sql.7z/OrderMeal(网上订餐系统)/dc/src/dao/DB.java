package dao;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;





public class DB {

	private Connection conn;
	public Connection getconn(){
		
		
			try {
				Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
				String url="jdbc:sqlserver://192.168.8.254:1433;databasename=restrant";

					conn=DriverManager.getConnection(url,"sa","123456");
			} catch (ClassNotFoundException e) {
				
				e.printStackTrace();
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
			
		return conn;
}
	public static void main(String[] args) {
		System.out.println(new DB().getconn());
	}
}
