package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import bean.foodInfo;

public class foodInfodao {
	
	private Connection conn;
	private ResultSet rs;
	private PreparedStatement ps;
	
	public void clearUp(){
		try {
			if(rs!=null){rs.close();}
			if(ps!=null){ps.close();}
			if(conn!=null){conn.close();}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
public List getall(){
	conn=new DB().getconn();
	String sql="select * from foodInfo";
	List<foodInfo> list =new ArrayList<foodInfo>();
	
	try {
		ps=conn.prepareStatement(sql);
		rs=ps.executeQuery();
		while(rs.next()){
			foodInfo fd=new foodInfo();
			fd.setFoodID(rs.getString("foodID"));
			fd.setFoodName(rs.getString("foodName"));
			fd.setRemark(rs.getString("remark"));
			fd.setFoodPrice(rs.getString("foodPrice"));
			fd.setDescription(rs.getString("description"));
			fd.setFoodImage(rs.getString("foodImage"));
			
			list.add(fd);
		}
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}finally{
		this.clearUp();
		
	}
	
	return list;
	
}
public foodInfo selectxq(String foodID){
	foodInfo fd=null;
	conn=new DB().getconn();
	String sql="select * from foodInfo where foodID='"+foodID+"'";
	try {
		ps=conn.prepareStatement(sql);
		rs=ps.executeQuery();
		while(rs.next()){
			 fd=new foodInfo();
			fd.setFoodID(rs.getString("foodID"));
			fd.setFoodName(rs.getString("foodName"));
			fd.setRemark(rs.getString("remark"));
			fd.setFoodPrice(rs.getString("foodPrice"));
			fd.setDescription(rs.getString("description"));
			fd.setFoodImage(rs.getString("foodImage"));
			
			
		}
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}finally{
		this.clearUp();
	}
	return fd;
	
	
	
}


public static void main(String[] args) {
	//List<foodInfo> list=new foodInfodao().getall();
	//System.out.println(list);
	
	foodInfo fd=new foodInfodao().selectxq("01");
	System.out.println(fd);
}
}
