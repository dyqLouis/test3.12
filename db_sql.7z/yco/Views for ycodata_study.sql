
conn sys/sys123@orcl as sysdba;
grant create view to roster;   ----�ù���Ա����Ȩ
grant create view to ycodata_study;   ----�ù���Ա����Ȩ
grant connect,resource to ycodata_study with admin option; 
grant connect,resource to roster with admin option; 

---create tablespace YCO_DATA datafile 'E:\oracle11g\oradata\YCO_DATA.dbf' size 50M autoextend on;
---create tablespace YCO_IDX datafile 'E:\oracle11g\oradata\YCO_IDX.dbf' size 50M autoextend on;


---��roster.dmp�е����ݵ��� orcl���ݿ��У�����CMD������ֱ�����������
  ---  imp roster/a123456@orcl full=y file=J:\Java\Armitage\sql\roster.dmp ignore=y

roster.dmp��������ͼ������Щ����








conn ycodata_study/a123456@orcl;

create or replace view v_roster_user_data_permission as
select "ID",
       "DB_VERSION_STAMP",
       "UPDATE_BY_ACTOR",
       "LAST_UPDATE_TIME",
       "USER_ID",
       "BUSINESS_UNIT",
       "DEPARTMENT",
       "SECTION",
       "GROUP_ID"
  from rst_secu_user_access_data

create or replace view v_roster_teams as
select "ID",
       "DB_VERSION_STAMP",
       "UPDATE_BY_ACTOR",
       "LAST_UPDATE_TIME",
       "BUSINESS_UNIT",
       "DEPARTMENT",
       "SECTION",
       "GROUP_ID",
       "TEAM",
       "REMARK",
       "IS_ACTIVE",
       "SQUAD"
  from rst_teams

create or replace view v_roster_staff_permissions as
select permission_code, u.user_id
  from rst_secu_role_access t,
       rst_secu_user        u
 where t.role_code = u.role_code
  and u.is_active = 'Y'

create or replace view v_roster_staff_info as
select user_id staffNo,
       password,
       chinese_name staffName,
       english_name staffNameEn,
       email_address emailAddress,
       business_unit businessUnit,
       department,
       section,
       role_code roleName,
       data_access_level dataAccessLevel,
       is_active active
  from rst_secu_user t
 where t.is_active = 'Y'

create or replace view v_roster_holiday_type as
select "ID",
       "DB_VERSION_STAMP",
       "UPDATE_BY_ACTOR",
       "LAST_UPDATE_TIME",
       "SHORT_HOLIDAY_TYPE_NAME",
       "HOLIDAY_TYPE_NAME",
       "HOLIDAY_TYPE_ENGLISH_NAME",
       "IS_SPECIAL",
       "IS_ACTIVE",
       "IS_INCLUDE",
       "IS_CALLOT"
  from rst_holiday_type
 where is_active = 'Y'

create or replace view v_roster_basic_shift_plan as
select "ID",
       "DB_VERSION_STAMP",
       "UPDATE_BY_ACTOR",
       "LAST_UPDATE_TIME",
       "STAFF_ID",
       "STAFF_NAME",
       "BUSINESS_UNIT",
       "DEPARTMENT",
       "SECTION",
       "GROUP_ID",
       "TEAM",
       "TEAM_SEQUENCE",
       "SHIFT_PLAN_DATE",
       "SHIFT_PLAN_ACTION",
       "TEMP_PLAN_ACTION",
       "TEMP_PLAN_ACTION_STATUS",
       "TEMP_PLAN_REMARK",
       "IS_TEMP_PLAN_CONFIRMED",
       "FIRST_PLAN_ACTION",
       "SHIFT_PLAN_ACTION_STATUS",
       "IS_MANPOWER",
       "REMARK",
       "CHANGE_REASON",
       "MANUAL_MODIFY",
       "POSITION",
       "IS_TRAINING",
       "SHIFT_CONTENT",
       "SQUAD"
  from rst_basic_shift_plan

create or replace view v_roster_actual_shift_action as
select "ID",
       "DB_VERSION_STAMP",
       "UPDATE_BY_ACTOR",
       "LAST_UPDATE_TIME",
       "STAFF_ID",
       "STAFF_NAME",
       "BUSINESS_UNIT",
       "DEPARTMENT",
       "SECTION",
       "GROUP_ID",
       "TEAM",
       "TEAM_SEQUENCE",
       "SHIFT_PLAN_DATE",
       "SHIFT_PLAN_ACTION",
       "FIRST_PLAN_ACTION",
       "SHIFT_PLAN_ACTION_STATUS",
       "IS_MANPOWER",
       "OT_TYPE",
       "OT_HOURS",
       "REMARK",
       "CHANGE_REASON",
       "MANUAL_MODIFY",
       "POSITION",
       "IS_TRAINING",
       "SHIFT_CONTENT",
       "SQUAD"
  from rst_actual_shift_action

commit;