------------------------------------------------------
-- Export file for user ROSTER                      --
-- Created by Administrator on 2014/11/15, 23:59:39 --
------------------------------------------------------

spool roster.log

prompt
prompt Creating table RST_ACTUAL_SHIFT_ACTION

prompt
create table roster.RST_ACTUAL_SHIFT_ACTION
(
  id                       NUMBER(9) not null,
  db_version_stamp         NUMBER(9) not null,
  update_by_actor          VARCHAR2(30) not null,
  last_update_time         DATE not null,
  staff_id                 VARCHAR2(10) not null,
  staff_name               VARCHAR2(30) not null,
  business_unit            VARCHAR2(30) not null,
  department               VARCHAR2(30) not null,
  section                  VARCHAR2(20) not null,
  group_id                 VARCHAR2(20) not null,
  team                     VARCHAR2(20) not null,
  team_sequence            NUMBER(3) not null,
  shift_plan_date          DATE not null,
  shift_plan_action        VARCHAR2(20) not null,
  first_plan_action        VARCHAR2(20) not null,
  shift_plan_action_status VARCHAR2(20) not null,
  is_manpower              VARCHAR2(1) default 'N',
  ot_type                  VARCHAR2(20),
  ot_hours                 NUMBER(2),
  remark                   VARCHAR2(200),
  change_reason            VARCHAR2(200),
  manual_modify            VARCHAR2(1),
  position                 VARCHAR2(30),
  is_training              VARCHAR2(1),
  shift_content            VARCHAR2(30),
  squad                    VARCHAR2(30)
)
tablespace YCO_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 17M
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table roster.RST_ACTUAL_SHIFT_ACTION
  add constraint PK_RST_ACTUAL_SHIFT_ACTION primary key (ID)
  using index 
  tablespace YCO_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 2M
    next 1M
    minextents 1
    maxextents unlimited
  );
grant select on roster.RST_ACTUAL_SHIFT_ACTION to YCODATA_STUDY;

prompt
prompt Creating table RST_BASIC_SHIFT_PLAN

prompt
create table roster.RST_BASIC_SHIFT_PLAN
(
  id                       NUMBER(9) not null,
  db_version_stamp         NUMBER(9) not null,
  update_by_actor          VARCHAR2(30) not null,
  last_update_time         DATE not null,
  staff_id                 VARCHAR2(10) not null,
  staff_name               VARCHAR2(30) not null,
  business_unit            VARCHAR2(30) not null,
  department               VARCHAR2(30) not null,
  section                  VARCHAR2(20) not null,
  group_id                 VARCHAR2(20) not null,
  team                     VARCHAR2(20) not null,
  team_sequence            NUMBER(3) not null,
  shift_plan_date          DATE not null,
  shift_plan_action        VARCHAR2(20) not null,
  temp_plan_action         VARCHAR2(20),
  temp_plan_action_status  VARCHAR2(20),
  temp_plan_remark         VARCHAR2(200),
  is_temp_plan_confirmed   VARCHAR2(1),
  first_plan_action        VARCHAR2(20) not null,
  shift_plan_action_status VARCHAR2(20) not null,
  is_manpower              VARCHAR2(1) default 'N',
  remark                   VARCHAR2(200),
  change_reason            VARCHAR2(200),
  manual_modify            VARCHAR2(1),
  position                 VARCHAR2(30),
  is_training              VARCHAR2(1),
  shift_content            VARCHAR2(30),
  squad                    VARCHAR2(30)
)
tablespace YCO_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 296M
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table roster.RST_BASIC_SHIFT_PLAN
  add constraint PK_RST_BASIC_SHIFT_PLAN primary key (ID)
  using index 
  tablespace YCO_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 37M
    next 1M
    minextents 1
    maxextents unlimited
  );
create bitmap index roster.BASIC_INDEX1 on roster.RST_BASIC_SHIFT_PLAN (STAFF_ID, SHIFT_PLAN_DATE)
  tablespace YCO_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 127M
    next 1M
    minextents 1
    maxextents unlimited
  );
create index roster.BASIC_INDEX2 on roster.RST_BASIC_SHIFT_PLAN (BUSINESS_UNIT, DEPARTMENT, SECTION, GROUP_ID, SHIFT_PLAN_DATE)
  tablespace YCO_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 128M
    next 1M
    minextents 1
    maxextents unlimited
  );
grant select on roster.RST_BASIC_SHIFT_PLAN to YCODATA_STUDY;

prompt
prompt Creating table RST_DATA_DICTIONARY

prompt
create table roster.RST_DATA_DICTIONARY
(
  type_code       VARCHAR2(4) not null,
  type_code_name  VARCHAR2(20) not null,
  data_list_id    VARCHAR2(20) not null,
  data_list_order NUMBER(9) not null,
  data_list_name  VARCHAR2(30) not null
)
tablespace YCO_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table roster.RST_DATA_DICTIONARY
  add constraint PK_RST_DATA_DICTIONARY primary key (TYPE_CODE, DATA_LIST_ID)
  using index 
  tablespace YCO_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table RST_HOLIDAY_TYPE
prompt 
prompt
create table roster.RST_HOLIDAY_TYPE
(
  id                        NUMBER(9) not null,
  db_version_stamp          NUMBER(9) not null,
  update_by_actor           VARCHAR2(30) not null,
  last_update_time          DATE not null,
  short_holiday_type_name   VARCHAR2(4) not null,
  holiday_type_name         VARCHAR2(60) not null,
  holiday_type_english_name VARCHAR2(60),
  is_special                VARCHAR2(1) not null,
  is_active                 VARCHAR2(1) not null,
  is_include                VARCHAR2(1),
  is_callot                 VARCHAR2(1)
)
tablespace YCO_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table roster.RST_HOLIDAY_TYPE
  add constraint PK_RST_HOLIDAY_TYPE primary key (ID)
  using index 
  tablespace YCO_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
grant select on roster.RST_HOLIDAY_TYPE to YCODATA_STUDY;

prompt
prompt Creating table RST_JOB_CHANGE_BOOKING

prompt
create table roster.RST_JOB_CHANGE_BOOKING
(
  id                 NUMBER(9) not null,
  db_version_stamp   NUMBER(9) not null,
  update_by_actor    VARCHAR2(30) not null,
  last_update_time   DATE not null,
  staff_id           VARCHAR2(10) not null,
  staff_name         VARCHAR2(30) not null,
  from_business_unit VARCHAR2(30) not null,
  from_department    VARCHAR2(30) not null,
  from_section       VARCHAR2(20) not null,
  to_business_unit   VARCHAR2(30) not null,
  to_department      VARCHAR2(30) not null,
  to_section         VARCHAR2(20) not null,
  effective_date     DATE not null,
  leave_team_date    DATE not null,
  is_active          VARCHAR2(1) not null
)
tablespace YCO_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 128K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table roster.RST_JOB_CHANGE_BOOKING
  add constraint PK_RST_JOB_CHANGE_BOOKING primary key (ID)
  using index 
  tablespace YCO_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table RST_LEGAL_HOLIDAY
prompt 
prompt
create table roster.RST_LEGAL_HOLIDAY
(
  id                   NUMBER(9) not null,
  db_version_stamp     NUMBER(9) not null,
  update_by_actor      VARCHAR2(30) not null,
  last_update_time     DATE not null,
  start_date           DATE not null,
  end_date             DATE not null,
  legal_holiday_name   VARCHAR2(40) not null,
  is_apply_to_all_year VARCHAR2(1) not null,
  is_active            VARCHAR2(1) not null
)
tablespace YCO_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table roster.RST_LEGAL_HOLIDAY
  add constraint PK_RST_LEGAL_HOLIDAY primary key (ID)
  using index 
  tablespace YCO_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table RST_MANPOWER_ESTIMATION

prompt
create table roster.RST_MANPOWER_ESTIMATION
(
  id                    NUMBER(9) not null,
  db_version_stamp      NUMBER(9) not null,
  update_by_actor       VARCHAR2(30) not null,
  last_update_time      DATE not null,
  business_unit         VARCHAR2(30) not null,
  department            VARCHAR2(30) not null,
  section               VARCHAR2(20) not null,
  group_id              VARCHAR2(20) not null,
  position              VARCHAR2(30),
  estimate_date         DATE not null,
  shift                 VARCHAR2(1) not null,
  min_manpower_estimate NUMBER(5) not null,
  is_active             VARCHAR2(1) not null
)
tablespace YCO_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table roster.RST_MANPOWER_ESTIMATION
  add constraint PK_RST_MANPOWER_ESTIMATION primary key (ID)
  using index 
  tablespace YCO_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table RST_MANPOWER_REQUIRMENT

prompt
create table roster.RST_MANPOWER_REQUIRMENT
(
  id                   NUMBER(9) not null,
  db_version_stamp     NUMBER(9) not null,
  update_by_actor      VARCHAR2(30) not null,
  last_update_time     DATE not null,
  business_unit        VARCHAR2(30) not null,
  department           VARCHAR2(30) not null,
  section              VARCHAR2(20) not null,
  group_id             VARCHAR2(20) not null,
  team                 VARCHAR2(20) not null,
  year                 NUMBER(4) not null,
  month                NUMBER(2) not null,
  shift                VARCHAR2(1) not null,
  position             VARCHAR2(30),
  min_manpower_request NUMBER(5) not null,
  skip_flag            VARCHAR2(1),
  is_active            VARCHAR2(1) not null
)
tablespace YCO_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table roster.RST_MANPOWER_REQUIRMENT
  add constraint PK_RST_MANPOWER_REQUIRMENT primary key (ID)
  using index 
  tablespace YCO_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table RST_MONTH_END
prompt 
prompt
create table roster.RST_MONTH_END
(
  id               NUMBER(9) not null,
  db_version_stamp NUMBER(9) not null,
  update_by_actor  VARCHAR2(30) not null,
  last_update_time DATE not null,
  business_unit    VARCHAR2(30) not null,
  department       VARCHAR2(30) not null,
  section          VARCHAR2(20) not null,
  group_id         VARCHAR2(20) not null,
  year             NUMBER(4) not null,
  month            NUMBER(2) not null,
  is_submited      VARCHAR2(1) not null,
  is_completed     VARCHAR2(1) not null
)
tablespace YCO_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 256K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table roster.RST_MONTH_END
  add constraint PK_RST_MONTH_END primary key (ID)
  using index 
  tablespace YCO_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 128K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table RST_MONTH_SEQUENCE
prompt 
prompt
create table roster.RST_MONTH_SEQUENCE
(
  id                   NUMBER(9) not null,
  db_version_stamp     NUMBER(9) not null,
  update_by_actor      VARCHAR2(30) not null,
  last_update_time     DATE not null,
  business_unit        VARCHAR2(30) not null,
  department           VARCHAR2(30) not null,
  section              VARCHAR2(20) not null,
  group_id             VARCHAR2(20) not null,
  year                 NUMBER(4) not null,
  month                NUMBER(2) not null,
  mr_start_sequence    CLOB,
  mr_end_sequence      CLOB,
  ot_start_sequence    CLOB,
  ot_end_sequence      CLOB,
  ot_lh_start_sequence CLOB,
  ot_lh_end_sequence   CLOB,
  ex_start_sequence    CLOB,
  ex_end_sequence      CLOB,
  mr_original_seq      CLOB,
  ot_original_seq      CLOB,
  ot_lh_original_seq   CLOB,
  ex_original_seq      CLOB
)
tablespace YCO_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 30M
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table roster.RST_MONTH_SEQUENCE
  add constraint PK_RST_MONTH_SEQUENCE primary key (ID)
  using index 
  tablespace YCO_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 128K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table RST_MONTH_SEQ_SETTING

prompt
create table roster.RST_MONTH_SEQ_SETTING
(
  id               NUMBER,
  db_version_stamp NUMBER,
  update_by_actor  VARCHAR2(10),
  last_update_time DATE,
  business_unit    VARCHAR2(20),
  department       VARCHAR2(20),
  section          VARCHAR2(20),
  group_id         VARCHAR2(20),
  reset_per_month  VARCHAR2(1),
  reset_year_month VARCHAR2(400),
  is_active        VARCHAR2(1),
  seq_type         VARCHAR2(5)
)
tablespace YCO_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table RST_MR_PRESET_BY_SHIFT

prompt
create table roster.RST_MR_PRESET_BY_SHIFT
(
  id               NUMBER(9) not null,
  db_version_stamp NUMBER(9) not null,
  update_by_actor  VARCHAR2(30) not null,
  last_update_time DATE not null,
  business_unit    VARCHAR2(30) not null,
  department       VARCHAR2(30) not null,
  section          VARCHAR2(20) not null,
  group_id         VARCHAR2(20) not null,
  preset_date      DATE not null,
  shift            VARCHAR2(1) not null,
  mr_amount        NUMBER(3),
  is_active        VARCHAR2(1) not null
)
tablespace YCO_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 192K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table roster.RST_MR_PRESET_BY_SHIFT
  add constraint PK_RST_MR_PRESET_BY_SHIFT primary key (ID)
  using index 
  tablespace YCO_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table RST_MR_PRESET_BY_STAFF

prompt
create table roster.RST_MR_PRESET_BY_STAFF
(
  id               NUMBER(9) not null,
  db_version_stamp NUMBER(9) not null,
  update_by_actor  VARCHAR2(30) not null,
  last_update_time DATE not null,
  business_unit    VARCHAR2(30) not null,
  department       VARCHAR2(30) not null,
  section          VARCHAR2(20) not null,
  group_id         VARCHAR2(20) not null,
  preset_month     VARCHAR2(7) not null,
  staff_id         VARCHAR2(10) not null,
  staff_name       VARCHAR2(30) not null,
  mr_amount        NUMBER(3),
  is_active        VARCHAR2(1) not null
)
tablespace YCO_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 256K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table roster.RST_MR_PRESET_BY_STAFF
  add constraint PK_RST_MR_PRESET_BY_STAFF primary key (ID)
  using index 
  tablespace YCO_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table RST_MR_SHIFT_PLAN
prompt 
prompt
create table roster.RST_MR_SHIFT_PLAN
(
  id               NUMBER(9) not null,
  db_version_stamp NUMBER(9) not null,
  update_by_actor  VARCHAR2(30) not null,
  last_update_time DATE not null,
  staff_id         VARCHAR2(10) not null,
  staff_name       VARCHAR2(30) not null,
  team_sequence    NUMBER(3) not null,
  business_unit    VARCHAR2(30) not null,
  department       VARCHAR2(30) not null,
  section          VARCHAR2(20) not null,
  group_id         VARCHAR2(20) not null,
  team             VARCHAR2(20) not null,
  shift_plan_date  DATE not null,
  shift            VARCHAR2(10) not null,
  remark           VARCHAR2(200),
  is_confirmed     VARCHAR2(1) not null
)
tablespace YCO_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
  );
alter table roster.RST_MR_SHIFT_PLAN
  add constraint PK_RST_MR_SHIFT_PLAN primary key (ID)
  using index 
  tablespace YCO_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
  );

prompt
prompt Creating table RST_OT_PRESET_BY_SHIFT

prompt
create table roster.RST_OT_PRESET_BY_SHIFT
(
  id               NUMBER(9) not null,
  db_version_stamp NUMBER(9) not null,
  update_by_actor  VARCHAR2(30) not null,
  last_update_time DATE not null,
  business_unit    VARCHAR2(30) not null,
  department       VARCHAR2(30) not null,
  section          VARCHAR2(20) not null,
  group_id         VARCHAR2(20) not null,
  preset_date      DATE not null,
  shift            VARCHAR2(1) not null,
  ot_amount        NUMBER(3),
  ot_pattern       VARCHAR2(20) not null,
  is_active        VARCHAR2(1) not null
)
tablespace YCO_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
  );
alter table roster.RST_OT_PRESET_BY_SHIFT
  add constraint PK_RST_OT_PRESET_BY_SHIFT primary key (ID)
  using index 
  tablespace YCO_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
  );

prompt
prompt Creating table RST_OT_SHIFT_PLAN
prompt 
prompt
create table roster.RST_OT_SHIFT_PLAN
(
  id                   NUMBER(9) not null,
  db_version_stamp     NUMBER(9) not null,
  update_by_actor      VARCHAR2(30) not null,
  last_update_time     DATE not null,
  staff_id             VARCHAR2(10) not null,
  staff_name           VARCHAR2(30) not null,
  team_sequence        NUMBER(3) not null,
  business_unit        VARCHAR2(30) not null,
  department           VARCHAR2(30) not null,
  section              VARCHAR2(20) not null,
  group_id             VARCHAR2(20) not null,
  team                 VARCHAR2(20) not null,
  shift_plan_date      DATE not null,
  shift                VARCHAR2(10) not null,
  ot_type              VARCHAR2(10) not null,
  ot_position          VARCHAR2(30),
  ot_pattern           VARCHAR2(20),
  orginal_shift_action VARCHAR2(10) not null,
  remark               VARCHAR2(200),
  is_confirmed         VARCHAR2(1) not null
)
tablespace YCO_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
  );
alter table roster.RST_OT_SHIFT_PLAN
  add constraint PK_RST_OT_SHIFT_PLAN primary key (ID)
  using index 
  tablespace YCO_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
  );

prompt
prompt Creating table RST_OT_SHIFT_SETTING

prompt
create table roster.RST_OT_SHIFT_SETTING
(
  id               NUMBER(9) not null,
  db_version_stamp NUMBER(9) not null,
  update_by_actor  VARCHAR2(30) not null,
  last_update_time DATE not null,
  business_unit    VARCHAR2(30) not null,
  department       VARCHAR2(30) not null,
  section          VARCHAR2(20) not null,
  group_id         VARCHAR2(20) not null,
  setting_date     DATE not null,
  shift            VARCHAR2(1) not null,
  ot_type          VARCHAR2(10) not null,
  ot_position      VARCHAR2(30),
  ot_amount        NUMBER(3) not null,
  ot_pattern       VARCHAR2(20),
  is_active        VARCHAR2(1) not null
)
tablespace YCO_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table roster.RST_OT_SHIFT_SETTING
  add constraint PK_RST_OT_SHIFT_SETTING primary key (ID)
  using index 
  tablespace YCO_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table RST_POSITION
prompt 
prompt
create table roster.RST_POSITION
(
  id                NUMBER(9) not null,
  db_version_stamp  NUMBER(9) not null,
  update_by_actor   VARCHAR2(30) not null,
  last_update_time  DATE not null,
  business_unit     VARCHAR2(30) not null,
  department        VARCHAR2(30) not null,
  section           VARCHAR2(20) not null,
  position          VARCHAR2(30) not null,
  is_active         VARCHAR2(1) not null,
  level_requirement VARCHAR2(200)
)
tablespace YCO_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table roster.RST_POSITION
  add constraint PK_RST_POSITION primary key (ID)
  using index 
  tablespace YCO_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table RST_RULE
prompt 
prompt
create table roster.RST_RULE
(
  id                         NUMBER(9) not null,
  db_version_stamp           NUMBER(9) not null,
  update_by_actor            VARCHAR2(30) not null,
  last_update_time           DATE not null,
  rule_desc                  VARCHAR2(200) not null,
  rule_level                 VARCHAR2(30) not null,
  rule_for_sections          VARCHAR2(200),
  rule_for_actions           VARCHAR2(200) not null,
  effective_date             DATE not null,
  overdue_date               DATE,
  able_to_disobey            VARCHAR2(1) not null,
  disobey_tips               VARCHAR2(200) not null,
  rule_type                  VARCHAR2(20) not null,
  rule_priority              NUMBER(2),
  able_to_disobey_in_typhoon VARCHAR2(1) not null,
  is_active                  VARCHAR2(1) not null
)
tablespace YCO_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table roster.RST_RULE
  add constraint PK_RST_RULE primary key (ID)
  using index 
  tablespace YCO_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table RST_RULE_CONDITION
prompt 
prompt
create table roster.RST_RULE_CONDITION
(
  rule_id          NUMBER(9) not null,
  condition_index  NUMBER(4) not null,
  left_expression  VARCHAR2(200) not null,
  functor          VARCHAR2(10),
  right_expression VARCHAR2(200),
  is_active        VARCHAR2(1),
  type             VARCHAR2(2)
)
tablespace YCO_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table roster.RST_RULE_CONDITION
  add constraint PK_RST_RULE_CONDITION primary key (RULE_ID, CONDITION_INDEX)
  using index 
  tablespace YCO_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table RST_SECTION
prompt 
prompt
create table roster.RST_SECTION
(
  id               NUMBER(9) not null,
  db_version_stamp NUMBER(9) not null,
  update_by_actor  VARCHAR2(30) not null,
  last_update_time DATE not null,
  business_unit    VARCHAR2(30) not null,
  department       VARCHAR2(30) not null,
  section          VARCHAR2(20) not null,
  section_detail   VARCHAR2(100) not null,
  is_active        VARCHAR2(1) not null
)
tablespace YCO_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table roster.RST_SECTION
  add constraint PK_RST_SECTION primary key (ID)
  using index 
  tablespace YCO_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table RST_SECU_PERMISSION

prompt
create table roster.RST_SECU_PERMISSION
(
  id               NUMBER(9) not null,
  db_version_stamp NUMBER(9) not null,
  update_by_actor  VARCHAR2(30) not null,
  last_update_time DATE not null,
  permission_code  VARCHAR2(100) not null,
  permission_desc  VARCHAR2(200) not null,
  menu_name        VARCHAR2(100) not null,
  order_by         NUMBER(9)
)
tablespace YCO_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table roster.RST_SECU_PERMISSION
  add constraint PK_RST_SECU_PERMISSION primary key (ID)
  using index 
  tablespace YCO_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table RST_SECU_ROLE
prompt 
prompt
create table roster.RST_SECU_ROLE
(
  id               NUMBER(9) not null,
  db_version_stamp NUMBER(9) not null,
  update_by_actor  VARCHAR2(30) not null,
  last_update_time DATE not null,
  role_code        VARCHAR2(30) not null,
  role_desc        VARCHAR2(200) not null,
  is_active        VARCHAR2(1) not null
)
tablespace YCO_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table roster.RST_SECU_ROLE
  add constraint PK_RST_SECU_ROLE primary key (ID)
  using index 
  tablespace YCO_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table RST_SECU_ROLE_ACCESS

prompt
create table roster.RST_SECU_ROLE_ACCESS
(
  id               NUMBER(9) not null,
  db_version_stamp NUMBER(9) not null,
  update_by_actor  VARCHAR2(30) not null,
  last_update_time DATE not null,
  role_code        VARCHAR2(30) not null,
  permission_code  VARCHAR2(100) not null
)
tablespace YCO_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 128K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table roster.RST_SECU_ROLE_ACCESS
  add constraint PK_RST_SECU_ROLE_ACCESS primary key (ID)
  using index 
  tablespace YCO_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
grant select on roster.RST_SECU_ROLE_ACCESS to YCODATA_STUDY;

prompt
prompt Creating table RST_SECU_USER
prompt 
prompt
create table roster.RST_SECU_USER
(
  id                NUMBER(9) not null,
  db_version_stamp  NUMBER(9) not null,
  update_by_actor   VARCHAR2(30) not null,
  last_update_time  DATE not null,
  user_id           VARCHAR2(10) not null,
  password          VARCHAR2(255),
  chinese_name      VARCHAR2(30),
  english_name      VARCHAR2(50),
  email_address     VARCHAR2(100),
  business_unit     VARCHAR2(30),
  department        VARCHAR2(30),
  section           VARCHAR2(20),
  data_access_level VARCHAR2(30) not null,
  role_code         VARCHAR2(30) not null,
  is_active         VARCHAR2(1) not null,
  default_option    VARCHAR2(50)
)
tablespace YCO_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table roster.RST_SECU_USER
  add constraint PK_RST_SECU_USER primary key (ID)
  using index 
  tablespace YCO_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
grant select on roster.RST_SECU_USER to YCODATA_STUDY;

prompt
prompt Creating table RST_SECU_USER_ACCESS_DATA

prompt
create table roster.RST_SECU_USER_ACCESS_DATA
(
  id               NUMBER(9) not null,
  db_version_stamp NUMBER(9) not null,
  update_by_actor  VARCHAR2(30) not null,
  last_update_time DATE not null,
  user_id          VARCHAR2(10) not null,
  business_unit    VARCHAR2(30) not null,
  department       VARCHAR2(30),
  section          VARCHAR2(20),
  group_id         VARCHAR2(20)
)
tablespace YCO_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table roster.RST_SECU_USER_ACCESS_DATA
  add constraint PK_RST_SECU_USER_ACCESS_DATA primary key (ID)
  using index 
  tablespace YCO_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
grant select on roster.RST_SECU_USER_ACCESS_DATA to YCODATA_STUDY;

prompt
prompt Creating table RST_SHIFT
prompt 
prompt
create table roster.RST_SHIFT
(
  id               NUMBER(9) not null,
  db_version_stamp NUMBER(9) not null,
  update_by_actor  VARCHAR2(30) not null,
  last_update_time DATE not null,
  shift            VARCHAR2(10) not null,
  shift_detail     VARCHAR2(200),
  start_time       DATE not null,
  end_time         DATE not null,
  is_active        VARCHAR2(1) not null,
  shift_content    VARCHAR2(30)
)
tablespace YCO_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table roster.RST_SHIFT
  add constraint PK_RST_SHIFT primary key (ID)
  using index 
  tablespace YCO_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table RST_SHIFT_PLAN_OPTION

prompt
create table roster.RST_SHIFT_PLAN_OPTION
(
  id                       NUMBER(9) not null,
  db_version_stamp         NUMBER(9) not null,
  update_by_actor          VARCHAR2(30) not null,
  last_update_time         DATE not null,
  business_unit            VARCHAR2(30) not null,
  department               VARCHAR2(30) not null,
  section                  VARCHAR2(20) not null,
  is_fmr_skip_booking      VARCHAR2(1) not null,
  is_ot_filter_refused     VARCHAR2(1) not null,
  is_ot_filter_next_leaved VARCHAR2(1) not null,
  is_ot_filter_fmr_booking VARCHAR2(1) not null
)
tablespace YCO_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table roster.RST_SHIFT_PLAN_OPTION
  add constraint PK_RST_SHIFT_PLAN_OPTION primary key (ID)
  using index 
  tablespace YCO_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table RST_SHIFT_PLAN_PATTERN

prompt
create table roster.RST_SHIFT_PLAN_PATTERN
(
  id                  NUMBER(9) not null,
  db_version_stamp    NUMBER(9) not null,
  update_by_actor     VARCHAR2(30) not null,
  last_update_time    DATE not null,
  business_unit       VARCHAR2(30) not null,
  department          VARCHAR2(30) not null,
  section             VARCHAR2(20) not null,
  type                VARCHAR2(20) not null,
  plan_pattern        VARCHAR2(200),
  plan_pattern_remark VARCHAR2(100) not null,
  is_active           VARCHAR2(1) not null
)
tablespace YCO_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table roster.RST_SHIFT_PLAN_PATTERN
  add constraint PK_RST_SHIFT_PLAN_PATTERN primary key (ID)
  using index 
  tablespace YCO_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table RST_STAFF
prompt 
prompt
create table roster.RST_STAFF
(
  id                  NUMBER(9) not null,
  db_version_stamp    NUMBER(9) not null,
  update_by_actor     VARCHAR2(30) not null,
  last_update_time    DATE not null,
  staff_id            VARCHAR2(10) not null,
  staff_name          VARCHAR2(30) not null,
  gender              VARCHAR2(10) not null,
  birthday            DATE not null,
  report_forduty_date DATE not null,
  staff_level         VARCHAR2(30) not null,
  is_new_trainee      VARCHAR2(1) not null,
  leave_date          DATE,
  annual_leave_day    NUMBER(3,1) not null,
  telephone_number    VARCHAR2(20) not null,
  eamil               VARCHAR2(50),
  dwelling_place      VARCHAR2(200),
  business_unit       VARCHAR2(30) not null,
  department          VARCHAR2(30) not null,
  section             VARCHAR2(20) not null,
  main_position       VARCHAR2(30) not null,
  remark              VARCHAR2(200),
  change_reason       VARCHAR2(200),
  is_active           VARCHAR2(1) not null,
  married             VARCHAR2(255 CHAR),
  departmant          VARCHAR2(255 CHAR),
  group_id            VARCHAR2(255 CHAR),
  team                VARCHAR2(255 CHAR)
)
tablespace YCO_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 320K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table roster.RST_STAFF
  add constraint PK_RST_STAFF primary key (ID)
  using index 
  tablespace YCO_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 128K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table RST_STAFF_ANNUAL_INFO

prompt
create table roster.RST_STAFF_ANNUAL_INFO
(
  id               NUMBER(9) not null,
  db_version_stamp NUMBER(9) not null,
  update_by_actor  VARCHAR2(30) not null,
  last_update_time DATE not null,
  staff_id         VARCHAR2(10) not null,
  year             NUMBER(4) not null,
  annual_leave_day NUMBER(3,1) not null,
  remark           VARCHAR2(200),
  is_active        VARCHAR2(1) not null
)
tablespace YCO_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 512K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table roster.RST_STAFF_ANNUAL_INFO
  add constraint PK_RST_STAFF_ANNUAL_INFO primary key (ID)
  using index 
  tablespace YCO_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 192K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table RST_STAFF_FLEXIBLE_MR

prompt
create table roster.RST_STAFF_FLEXIBLE_MR
(
  id               NUMBER(9) not null,
  db_version_stamp NUMBER(9) not null,
  update_by_actor  VARCHAR2(30) not null,
  last_update_time DATE not null,
  staff_id         VARCHAR2(10) not null,
  staff_name       VARCHAR2(30) not null,
  mr_type          VARCHAR2(20) not null,
  start_date       DATE not null,
  end_date         DATE not null,
  total_leave_day  NUMBER(3),
  apply_reason     VARCHAR2(200),
  approve_by       VARCHAR2(30) not null,
  is_active        VARCHAR2(1) not null,
  half             VARCHAR2(1),
  last_plan_action VARCHAR2(20)
)
tablespace YCO_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 6M
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table roster.RST_STAFF_FLEXIBLE_MR
  add constraint PK_RST_STAFF_FLEXIBLE_MR primary key (ID)
  using index 
  tablespace YCO_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 2M
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table RST_STAFF_HIS
prompt 
prompt
create table roster.RST_STAFF_HIS
(
  id               NUMBER(9) not null,
  db_version_stamp NUMBER(9) not null,
  update_by_actor  VARCHAR2(30) not null,
  last_update_time DATE not null,
  staff_id         VARCHAR2(10) not null,
  staff_name       VARCHAR2(30) not null,
  before_image     VARCHAR2(500) not null,
  after_image      VARCHAR2(500) not null,
  change_reason    VARCHAR2(200)
)
tablespace YCO_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 256K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table roster.RST_STAFF_HIS
  add constraint PK_RST_STAFF_HIS primary key (ID)
  using index 
  tablespace YCO_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table RST_STAFF_HOLIDAY
prompt 
prompt
create table roster.RST_STAFF_HOLIDAY
(
  id                      NUMBER(9) not null,
  db_version_stamp        NUMBER(9) not null,
  update_by_actor         VARCHAR2(30) not null,
  last_update_time        DATE not null,
  staff_id                VARCHAR2(10) not null,
  staff_name              VARCHAR2(30) not null,
  short_holiday_type_name VARCHAR2(4) not null,
  apply_date              DATE not null,
  is_half_of_date         VARCHAR2(1) not null,
  f_a_tag_of_half         VARCHAR2(1),
  remark                  VARCHAR2(200),
  is_active               VARCHAR2(1) not null,
  last_plan_action        VARCHAR2(20)
)
tablespace YCO_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 8M
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table roster.RST_STAFF_HOLIDAY
  add constraint PK_RST_STAFF_HOLIDAY primary key (ID)
  using index 
  tablespace YCO_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 2M
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table RST_STAFF_LEVEL
prompt 
prompt
create table roster.RST_STAFF_LEVEL
(
  id               NUMBER(9) not null,
  db_version_stamp NUMBER(9) not null,
  update_by_actor  VARCHAR2(30) not null,
  last_update_time DATE not null,
  business_unit    VARCHAR2(30) not null,
  department       VARCHAR2(30) not null,
  section          VARCHAR2(20) not null,
  staff_level      VARCHAR2(30) not null,
  staff_level_desc VARCHAR2(100),
  is_active        VARCHAR2(1) not null
)
tablespace YCO_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table roster.RST_STAFF_LEVEL
  add constraint PK_RST_STAFF_LEVEL primary key (ID)
  using index 
  tablespace YCO_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table RST_STAFF_MONTH_END

prompt
create table roster.RST_STAFF_MONTH_END
(
  id                NUMBER(9) not null,
  db_version_stamp  NUMBER(9) not null,
  update_by_actor   VARCHAR2(30) not null,
  last_update_time  DATE not null,
  year              NUMBER(4) not null,
  month             NUMBER(2) not null,
  staff_id          VARCHAR2(10) not null,
  mr_rest           NUMBER(5,1) not null,
  al_rest           NUMBER(4,1) not null,
  is_full_month_end VARCHAR2(1) not null,
  left_ot_hours     NUMBER(4),
  left_mr           NUMBER(4,1),
  ot_to_next_month  NUMBER(4,1),
  ot_to_mr          NUMBER(4,1),
  normal_mr_needed  NUMBER(4),
  no_of_mr_left     NUMBER(4,1)
)
tablespace YCO_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 4M
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table roster.RST_STAFF_MONTH_END
  add constraint PK_RST_STAFF_MONTH_END primary key (ID)
  using index 
  tablespace YCO_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 2M
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table RST_STAFF_MR_TREATMENT

prompt
create table roster.RST_STAFF_MR_TREATMENT
(
  id               NUMBER not null,
  db_version_stamp NUMBER,
  update_by_actor  VARCHAR2(20),
  last_update_time DATE,
  staff_id         VARCHAR2(10),
  start_year_month VARCHAR2(7),
  end_year_month   VARCHAR2(7),
  is_active        VARCHAR2(1)
)
tablespace YCO_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 128K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table roster.RST_STAFF_MR_TREATMENT
  add constraint RST_STAFF_MR_TREATMENT_PK primary key (ID)
  using index 
  tablespace YCO_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table RST_STAFF_OT_TRANSFORM_SETTING

prompt
create table roster.RST_STAFF_OT_TRANSFORM_SETTING
(
  id               NUMBER,
  db_version_stamp NUMBER,
  update_by_actor  VARCHAR2(10),
  last_update_time DATE,
  staff_id         VARCHAR2(10),
  year             NUMBER,
  month            NUMBER,
  ot_to_mr         NUMBER,
  ot_to_next_month NUMBER
)
tablespace YCO_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table RST_STAFF_PLAN_PATTERN

prompt
create table roster.RST_STAFF_PLAN_PATTERN
(
  id                 NUMBER(9) not null,
  db_version_stamp   NUMBER(9) not null,
  update_by_actor    VARCHAR2(30) not null,
  last_update_time   DATE not null,
  staff_id           VARCHAR2(10) not null,
  staff_name         VARCHAR2(30) not null,
  business_unit      VARCHAR2(30) not null,
  department         VARCHAR2(30) not null,
  section            VARCHAR2(20) not null,
  group_id           VARCHAR2(20) not null,
  team               VARCHAR2(20) not null,
  shift_plan_type    VARCHAR2(10) not null,
  shift_plan_pattern VARCHAR2(200),
  start_shift_index  NUMBER(3),
  effective_date     DATE not null,
  end_date           DATE,
  remark             VARCHAR2(200) not null,
  change_reason      VARCHAR2(200),
  is_active          VARCHAR2(1) not null,
  squad              VARCHAR2(30)
)
tablespace YCO_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 640K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table roster.RST_STAFF_PLAN_PATTERN
  add constraint PK_RST_STAFF_PLAN_PATTERN primary key (ID)
  using index 
  tablespace YCO_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 128K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table RST_STAFF_POSITION
prompt 
prompt
create table roster.RST_STAFF_POSITION
(
  id               NUMBER(9) not null,
  db_version_stamp NUMBER(9) not null,
  update_by_actor  VARCHAR2(30) not null,
  last_update_time DATE not null,
  staff_id         VARCHAR2(10) not null,
  staff_name       VARCHAR2(30) not null,
  business_unit    VARCHAR2(30) not null,
  department       VARCHAR2(30) not null,
  section          VARCHAR2(20) not null,
  position         VARCHAR2(30) not null,
  is_new_trainee   VARCHAR2(1) not null,
  effective_date   DATE not null,
  is_main_position VARCHAR2(1),
  change_reason    VARCHAR2(200),
  is_active        VARCHAR2(1) not null
)
tablespace YCO_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 320K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table roster.RST_STAFF_POSITION
  add constraint PK_RST_STAFF_POSITION primary key (ID)
  using index 
  tablespace YCO_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 128K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table RST_STAFF_SEQ_INCLUDE

prompt
create table roster.RST_STAFF_SEQ_INCLUDE
(
  id               NUMBER,
  db_version_stamp NUMBER,
  update_by_actor  VARCHAR2(16),
  last_update_time DATE,
  staff_id         VARCHAR2(10),
  start_date       DATE,
  end_date         DATE,
  mr_flag          VARCHAR2(2),
  ot_flag          VARCHAR2(2),
  ho_flag          VARCHAR2(2),
  ex_flag          VARCHAR2(2),
  status           VARCHAR2(2)
)
tablespace YCO_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table RST_STAFF_SKIP_INFO

prompt
create table roster.RST_STAFF_SKIP_INFO
(
  id               NUMBER(9) not null,
  db_version_stamp NUMBER(9) not null,
  update_by_actor  VARCHAR2(30) not null,
  last_update_time DATE not null,
  business_unit    VARCHAR2(30) not null,
  department       VARCHAR2(30) not null,
  section          VARCHAR2(20) not null,
  group_id         VARCHAR2(20) not null,
  staff_id         VARCHAR2(10) not null,
  staff_name       VARCHAR2(30) not null,
  action_date      DATE not null,
  action_type      VARCHAR2(10) not null,
  action_shift     VARCHAR2(10) not null,
  is_rejected      VARCHAR2(1) not null,
  reason           VARCHAR2(200)
)
tablespace YCO_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 128K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table roster.RST_STAFF_SKIP_INFO
  add constraint PK_RST_STAFF_SKIP_INFO primary key (ID)
  using index 
  tablespace YCO_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table RST_STAFF_TEAM_INFO

prompt
create table roster.RST_STAFF_TEAM_INFO
(
  id               NUMBER(9) not null,
  db_version_stamp NUMBER(9) not null,
  update_by_actor  VARCHAR2(30) not null,
  last_update_time DATE not null,
  staff_id         VARCHAR2(10) not null,
  staff_name       VARCHAR2(30) not null,
  business_unit    VARCHAR2(30) not null,
  department       VARCHAR2(30) not null,
  section          VARCHAR2(20) not null,
  group_id         VARCHAR2(20) not null,
  team             VARCHAR2(20) not null,
  team_sequence    NUMBER(3) not null,
  position         VARCHAR2(30) not null,
  effective_date   DATE not null,
  end_date         DATE,
  staff_level      VARCHAR2(30) not null,
  change_reason    VARCHAR2(200),
  is_active        VARCHAR2(1) not null,
  squad            VARCHAR2(20)
)
tablespace YCO_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 768K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table roster.RST_STAFF_TEAM_INFO
  add constraint PK_RST_STAFF_TEAM_INFO primary key (ID)
  using index 
  tablespace YCO_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 128K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table RST_SYSTEM_LOG
prompt 
prompt
create table roster.RST_SYSTEM_LOG
(
  id           NUMBER not null,
  event_source VARCHAR2(100) not null,
  op_date      DATE not null,
  op_user      VARCHAR2(30) not null,
  log_content  VARCHAR2(2000) not null
)
tablespace YCO_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
  );
alter table roster.RST_SYSTEM_LOG
  add constraint RST_SYSTEM_LOG_PK primary key (ID)
  using index 
  tablespace YCO_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
  );

prompt
prompt Creating table RST_TEAMS
prompt 
prompt
create table roster.RST_TEAMS
(
  id               NUMBER(9) not null,
  db_version_stamp NUMBER(9) not null,
  update_by_actor  VARCHAR2(30) not null,
  last_update_time DATE not null,
  business_unit    VARCHAR2(30) not null,
  department       VARCHAR2(30) not null,
  section          VARCHAR2(20) not null,
  group_id         VARCHAR2(20) not null,
  team             VARCHAR2(20) not null,
  remark           VARCHAR2(200),
  is_active        VARCHAR2(1) not null,
  squad            VARCHAR2(20)
)
tablespace YCO_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table roster.RST_TEAMS
  add constraint PK_RST_TEAMS primary key (ID)
  using index 
  tablespace YCO_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
grant select on roster.RST_TEAMS to YCODATA_STUDY;

prompt
prompt Creating table RST_TEAM_PLAN_PATTERN

prompt
create table roster.RST_TEAM_PLAN_PATTERN
(
  id                 NUMBER(9) not null,
  db_version_stamp   NUMBER(9) not null,
  update_by_actor    VARCHAR2(30) not null,
  last_update_time   DATE not null,
  parent_team_id     NUMBER(9),
  start_date         DATE,
  end_date           DATE,
  shift_plan_type    VARCHAR2(10) not null,
  shift_plan_pattern VARCHAR2(200),
  start_shift_index  NUMBER(3)
)
tablespace YCO_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 256K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table RST_TYPHOON
prompt 
prompt
create table roster.RST_TYPHOON
(
  id               NUMBER(9) not null,
  db_version_stamp NUMBER(9) not null,
  update_by_actor  VARCHAR2(30) not null,
  last_update_time DATE not null,
  typhoon_model    VARCHAR2(1) not null,
  remark           VARCHAR2(100)
)
tablespace YCO_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
  );
alter table roster.RST_TYPHOON
  add constraint PK_RST_TYPHOON primary key (ID)
  using index 
  tablespace YCO_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
  );

prompt
prompt Creating table TMP_RST_ACTUAL_SHIFT_ACTION

prompt
create table roster.TMP_RST_ACTUAL_SHIFT_ACTION
(
  id                       NUMBER(9) not null,
  db_version_stamp         NUMBER(9) not null,
  update_by_actor          VARCHAR2(30) not null,
  last_update_time         DATE not null,
  staff_id                 VARCHAR2(10) not null,
  staff_name               VARCHAR2(30) not null,
  business_unit            VARCHAR2(30) not null,
  department               VARCHAR2(30) not null,
  section                  VARCHAR2(20) not null,
  group_id                 VARCHAR2(20) not null,
  team                     VARCHAR2(20) not null,
  team_sequence            NUMBER(3) not null,
  shift_plan_date          DATE not null,
  shift_plan_action        VARCHAR2(20) not null,
  first_plan_action        VARCHAR2(20) not null,
  shift_plan_action_status VARCHAR2(20) not null,
  is_manpower              VARCHAR2(1),
  ot_type                  VARCHAR2(20),
  ot_hours                 NUMBER(2),
  remark                   VARCHAR2(200),
  change_reason            VARCHAR2(200),
  manual_modify            VARCHAR2(1),
  position                 VARCHAR2(30),
  is_training              VARCHAR2(1),
  shift_content            VARCHAR2(30),
  squad                    VARCHAR2(30)
)
tablespace YCO_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table TMP_RST_BASIC_SHIFT_PLAN

prompt
create table roster.TMP_RST_BASIC_SHIFT_PLAN
(
  id                       NUMBER(9) not null,
  db_version_stamp         NUMBER(9) not null,
  update_by_actor          VARCHAR2(30) not null,
  last_update_time         DATE not null,
  staff_id                 VARCHAR2(10) not null,
  staff_name               VARCHAR2(30) not null,
  business_unit            VARCHAR2(30) not null,
  department               VARCHAR2(30) not null,
  section                  VARCHAR2(20) not null,
  group_id                 VARCHAR2(20) not null,
  team                     VARCHAR2(20) not null,
  team_sequence            NUMBER(3) not null,
  shift_plan_date          DATE not null,
  shift_plan_action        VARCHAR2(20) not null,
  temp_plan_action         VARCHAR2(20),
  temp_plan_action_status  VARCHAR2(20),
  temp_plan_remark         VARCHAR2(200),
  is_temp_plan_confirmed   VARCHAR2(1),
  first_plan_action        VARCHAR2(20) not null,
  shift_plan_action_status VARCHAR2(20) not null,
  is_manpower              VARCHAR2(1),
  remark                   VARCHAR2(200),
  change_reason            VARCHAR2(200),
  manual_modify            VARCHAR2(1),
  position                 VARCHAR2(30),
  is_training              VARCHAR2(1),
  shift_content            VARCHAR2(30),
  squad                    VARCHAR2(30)
)
tablespace YCO_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 320K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table T_DICTIONARY
prompt 
prompt
create table roster.T_DICTIONARY
(
  id           NUMBER(19) not null,
  created_by   VARCHAR2(20 CHAR),
  created_date TIMESTAMP(6),
  updated_by   VARCHAR2(20 CHAR),
  updated_date TIMESTAMP(6),
  version      NUMBER(19),
  category     VARCHAR2(100 CHAR),
  text         VARCHAR2(200 CHAR),
  value        VARCHAR2(800 CHAR),
  sort         NUMBER(10)
)
tablespace ROSTER_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table roster.T_DICTIONARY
  add primary key (ID)
  using index 
  tablespace ROSTER_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table T_YCO_ARRANGED_PLAN
prompt
create table roster.T_YCO_ARRANGED_PLAN
(
  id               NUMBER(19) not null,
  created_by       VARCHAR2(20 CHAR),
  created_date     TIMESTAMP(6),
  updated_by       VARCHAR2(20 CHAR),
  updated_date     TIMESTAMP(6),
  version          NUMBER(19),
  step1_status     VARCHAR2(20 CHAR),
  shift            VARCHAR2(10 CHAR) not null,
  shift_date       DATE not null,
  step4_status     VARCHAR2(20 CHAR),
  step3_status     VARCHAR2(20 CHAR),
  step2_status     VARCHAR2(20 CHAR),
  plan_result_date TIMESTAMP(6),
  plan_staff_no    VARCHAR2(20 CHAR)
)
tablespace ROSTER_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table roster.T_YCO_ARRANGED_PLAN
  add primary key (ID)
  using index 
  tablespace ROSTER_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
create index roster.IDX_YCO_ARRANGED_PLAN on roster.T_YCO_ARRANGED_PLAN (SHIFT_DATE, SHIFT)
  tablespace ROSTER_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table T_YCO_ARRANGED_RESULT_SNAPSHOT

prompt
create table roster.T_YCO_ARRANGED_RESULT_SNAPSHOT
(
  id                 NUMBER(19) not null,
  created_by         VARCHAR2(20 CHAR),
  created_date       TIMESTAMP(6),
  updated_by         VARCHAR2(20 CHAR),
  updated_date       TIMESTAMP(6),
  version            NUMBER(19),
  contractor         VARCHAR2(40 CHAR),
  group_no           NUMBER(19),
  is_new_opened_yc   CHAR(1 CHAR),
  is_no_arranged     CHAR(1 CHAR),
  is_oneone_arranged CHAR(1 CHAR),
  is_r_arranged      CHAR(1 CHAR),
  pickup_yc_no       VARCHAR2(8 CHAR),
  pickup_yc_no_zone  VARCHAR2(20 CHAR),
  relax_period       VARCHAR2(255 CHAR),
  remark             VARCHAR2(60 CHAR),
  shift              VARCHAR2(10 CHAR) not null,
  shift_date         DATE not null,
  staff_name         VARCHAR2(30 CHAR),
  staff_no           VARCHAR2(10 CHAR),
  yc_no              VARCHAR2(8 CHAR),
  yc_no_zone         VARCHAR2(20 CHAR)
)
tablespace ROSTER_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table roster.T_YCO_ARRANGED_RESULT_SNAPSHOT
  add primary key (ID)
  using index 
  tablespace ROSTER_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
create index roster.IDX_YCO_AR_SNAPSHOT on roster.T_YCO_ARRANGED_RESULT_SNAPSHOT (SHIFT_DATE, SHIFT, STAFF_NO)
  tablespace ROSTER_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table T_YCO_ARRANGED_RESULT

prompt
create table roster.T_YCO_ARRANGED_RESULT
(
  id                 NUMBER(19) not null,
  created_by         VARCHAR2(20 CHAR),
  created_date       TIMESTAMP(6),
  updated_by         VARCHAR2(20 CHAR),
  updated_date       TIMESTAMP(6),
  version            NUMBER(19),
  contractor         VARCHAR2(40 CHAR),
  group_no           NUMBER(19),
  is_new_opened_yc   CHAR(1 CHAR),
  is_no_arranged     CHAR(1 CHAR),
  is_oneone_arranged CHAR(1 CHAR),
  is_r_arranged      CHAR(1 CHAR),
  pickup_yc_no       VARCHAR2(8 CHAR),
  pickup_yc_no_zone  VARCHAR2(20 CHAR),
  relax_period       VARCHAR2(255 CHAR),
  remark             VARCHAR2(60 CHAR),
  shift              VARCHAR2(10 CHAR) not null,
  shift_date         DATE not null,
  staff_name         VARCHAR2(30 CHAR),
  staff_no           VARCHAR2(10 CHAR),
  yc_no              VARCHAR2(8 CHAR),
  yc_no_zone         VARCHAR2(20 CHAR),
  snapshot_id        NUMBER(19)
)
tablespace ROSTER_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table roster.T_YCO_ARRANGED_RESULT
  add primary key (ID)
  using index 
  tablespace ROSTER_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table roster.T_YCO_ARRANGED_RESULT
  add constraint FK152D0E1FEF2CBFD foreign key (SNAPSHOT_ID)
  references roster.T_YCO_ARRANGED_RESULT_SNAPSHOT (ID);
create index roster.IDX_YCO_AR_SHIFT on roster.T_YCO_ARRANGED_RESULT (SHIFT_DATE, SHIFT, STAFF_NO)
  tablespace ROSTER_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table T_YCO_ARRANGED_RESULT_HIS

prompt
create table roster.T_YCO_ARRANGED_RESULT_HIS
(
  id               NUMBER(19) not null,
  created_by       VARCHAR2(20 CHAR),
  created_date     TIMESTAMP(6),
  updated_by       VARCHAR2(20 CHAR),
  updated_date     TIMESTAMP(6),
  version          NUMBER(19),
  new_pickup_yc_no VARCHAR2(8 CHAR),
  new_relax_period VARCHAR2(255 CHAR),
  new_remark       VARCHAR2(60 CHAR),
  new_staff_name   VARCHAR2(30 CHAR),
  new_staff_no     VARCHAR2(10 CHAR),
  new_yc_no        VARCHAR2(8 CHAR),
  old_pickup_yc_no VARCHAR2(8 CHAR),
  old_relax_period VARCHAR2(255 CHAR),
  old_remark       VARCHAR2(60 CHAR),
  old_staff_name   VARCHAR2(30 CHAR),
  old_staff_no     VARCHAR2(10 CHAR),
  old_yc_no        VARCHAR2(8 CHAR),
  shift            VARCHAR2(10 CHAR) not null,
  shift_date       DATE not null
)
tablespace ROSTER_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table roster.T_YCO_ARRANGED_RESULT_HIS
  add primary key (ID)
  using index 
  tablespace ROSTER_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
create index roster.IDX_YCO_ARH_SHIFT_HIS on roster.T_YCO_ARRANGED_RESULT_HIS (SHIFT_DATE, SHIFT)
  tablespace ROSTER_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table T_YCO_ARRANGED_YC
prompt 
prompt
create table roster.T_YCO_ARRANGED_YC
(
  id            NUMBER(19) not null,
  created_by    VARCHAR2(20 CHAR),
  created_date  TIMESTAMP(6),
  updated_by    VARCHAR2(20 CHAR),
  updated_date  TIMESTAMP(6),
  version       NUMBER(19),
  contractor    VARCHAR2(40 CHAR),
  pre_assigned  CHAR(1 CHAR),
  reserved      CHAR(1 CHAR),
  remark        VARCHAR2(60 CHAR),
  shift         VARCHAR2(10 CHAR) not null,
  shift_date    DATE not null,
  yc_no         VARCHAR2(8 CHAR),
  yc_zone       VARCHAR2(20 CHAR),
  special_yc    CHAR(1 CHAR),
  yc_mfrs       VARCHAR2(20 CHAR),
  yc_status     VARCHAR2(20 CHAR),
  yc_type       VARCHAR2(20 CHAR),
  yc_prop       VARCHAR2(30 CHAR),
  new_opened_yc CHAR(1 CHAR)
)
tablespace ROSTER_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table roster.T_YCO_ARRANGED_YC
  add primary key (ID)
  using index 
  tablespace ROSTER_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
create index roster.IDX_YCO_ARRANGED_YC on roster.T_YCO_ARRANGED_YC (SHIFT_DATE, SHIFT)
  tablespace ROSTER_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table T_YCO_ARRANGED_YCO
prompt 
prompt
create table roster.T_YCO_ARRANGED_YCO
(
  id           NUMBER(19) not null,
  created_by   VARCHAR2(20 CHAR),
  created_date TIMESTAMP(6),
  updated_by   VARCHAR2(20 CHAR),
  updated_date TIMESTAMP(6),
  version      NUMBER(19),
  contractor   VARCHAR2(40 CHAR),
  pre_assigned CHAR(1 CHAR),
  reserved     CHAR(1 CHAR),
  remark       VARCHAR2(60 CHAR),
  shift        VARCHAR2(10 CHAR) not null,
  shift_date   DATE not null,
  staff_name   VARCHAR2(30 CHAR),
  staff_no     VARCHAR2(10 CHAR)
)
tablespace ROSTER_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table roster.T_YCO_ARRANGED_YCO
  add primary key (ID)
  using index 
  tablespace ROSTER_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
create index roster.IDX_YCO_ARRANGED_YCO on roster.T_YCO_ARRANGED_YCO (SHIFT_DATE, SHIFT)
  tablespace ROSTER_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table T_YCO_AVAILABLE_YC
prompt 
prompt
create table roster.T_YCO_AVAILABLE_YC
(
  id            NUMBER(19) not null,
  created_by    VARCHAR2(20 CHAR),
  created_date  TIMESTAMP(6),
  updated_by    VARCHAR2(20 CHAR),
  updated_date  TIMESTAMP(6),
  version       NUMBER(19),
  shift         VARCHAR2(10 CHAR) not null,
  shift_date    DATE not null,
  yc_mfrs       VARCHAR2(20 CHAR),
  yc_no         VARCHAR2(8 CHAR),
  yc_status     VARCHAR2(20 CHAR),
  yc_type       VARCHAR2(20 CHAR),
  yc_zone       VARCHAR2(20 CHAR),
  special_yc    CHAR(1 CHAR),
  remark        VARCHAR2(30 CHAR),
  yc_prop       VARCHAR2(30 CHAR),
  new_opened_yc CHAR(1 CHAR)
)
tablespace ROSTER_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table roster.T_YCO_AVAILABLE_YC
  add primary key (ID)
  using index 
  tablespace ROSTER_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
create index roster.IDX_YCO_AVAILABLE_YC on roster.T_YCO_AVAILABLE_YC (SHIFT_DATE, SHIFT)
  tablespace ROSTER_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table T_YCO_CONTRACTOR
prompt 
prompt
create table roster.T_YCO_CONTRACTOR
(
  id           NUMBER(19) not null,
  created_by   VARCHAR2(20 CHAR),
  created_date TIMESTAMP(6),
  updated_by   VARCHAR2(20 CHAR),
  updated_date TIMESTAMP(6),
  version      NUMBER(19),
  name         VARCHAR2(60 CHAR),
  remark       VARCHAR2(200 CHAR),
  status       VARCHAR2(20 CHAR)
)
tablespace ROSTER_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table roster.T_YCO_CONTRACTOR
  add primary key (ID)
  using index 
  tablespace ROSTER_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table T_YCO_CONTR_ASSIGNED_YC

prompt
create table roster.T_YCO_CONTR_ASSIGNED_YC
(
  id           NUMBER(19) not null,
  created_by   VARCHAR2(20 CHAR),
  created_date TIMESTAMP(6),
  updated_by   VARCHAR2(20 CHAR),
  updated_date TIMESTAMP(6),
  version      NUMBER(19),
  contractor   VARCHAR2(40 CHAR),
  count        NUMBER(10),
  shift        VARCHAR2(10 CHAR) not null,
  shift_date   DATE not null
)
tablespace ROSTER_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table roster.T_YCO_CONTR_ASSIGNED_YC
  add primary key (ID)
  using index 
  tablespace ROSTER_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
create index roster.IDX_YCO_CONTR_ASSIGNED_YC on roster.T_YCO_CONTR_ASSIGNED_YC (SHIFT_DATE, SHIFT)
  tablespace ROSTER_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table T_YCO_CONTR_PRE_ASSIGNED

prompt
create table roster.T_YCO_CONTR_PRE_ASSIGNED
(
  id           NUMBER(19) not null,
  created_by   VARCHAR2(20 CHAR),
  created_date TIMESTAMP(6),
  updated_by   VARCHAR2(20 CHAR),
  updated_date TIMESTAMP(6),
  version      NUMBER(19),
  contractor   VARCHAR2(40 CHAR),
  pickup_yc_no VARCHAR2(8 CHAR),
  relax_period VARCHAR2(20 CHAR),
  remark       VARCHAR2(60 CHAR),
  shift        VARCHAR2(10 CHAR) not null,
  shift_date   DATE not null,
  staff_name   VARCHAR2(30 CHAR),
  staff_no     VARCHAR2(10 CHAR),
  yc_no        VARCHAR2(8 CHAR)
)
tablespace ROSTER_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table roster.T_YCO_CONTR_PRE_ASSIGNED
  add primary key (ID)
  using index 
  tablespace ROSTER_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
create index roster.IDX_YCO_CONTR_PRE_ASSIGNED on roster.T_YCO_CONTR_PRE_ASSIGNED (SHIFT_DATE, SHIFT)
  tablespace ROSTER_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table T_YCO_CON_MFRS
prompt 
prompt
create table roster.T_YCO_CON_MFRS
(
  id            NUMBER(19) not null,
  created_by    VARCHAR2(20 CHAR),
  created_date  TIMESTAMP(6),
  updated_by    VARCHAR2(20 CHAR),
  updated_date  TIMESTAMP(6),
  version       NUMBER(19),
  contractor_id NUMBER(19) not null,
  remark        VARCHAR2(20 CHAR),
  status        VARCHAR2(1 CHAR) not null
)
tablespace ROSTER_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table roster.T_YCO_CON_MFRS
  add primary key (ID)
  using index 
  tablespace ROSTER_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table T_YCO_CON_MFRS_DETAIL

prompt
create table roster.T_YCO_CON_MFRS_DETAIL
(
  id           NUMBER(19) not null,
  created_by   VARCHAR2(20 CHAR),
  created_date TIMESTAMP(6),
  updated_by   VARCHAR2(20 CHAR),
  updated_date TIMESTAMP(6),
  version      NUMBER(19),
  con_mfrs_id  NUMBER(19) not null,
  yc_mfrs_id   NUMBER(19) not null
)
tablespace ROSTER_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table roster.T_YCO_CON_MFRS_DETAIL
  add primary key (ID)
  using index 
  tablespace ROSTER_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table T_YCO_CON_PROP
prompt 
prompt
create table roster.T_YCO_CON_PROP
(
  id            NUMBER(19) not null,
  created_by    VARCHAR2(20 CHAR),
  created_date  TIMESTAMP(6),
  updated_by    VARCHAR2(20 CHAR),
  updated_date  TIMESTAMP(6),
  version       NUMBER(19),
  contractor_id NUMBER(19) not null,
  remark        VARCHAR2(20 CHAR),
  status        VARCHAR2(1 CHAR) not null
)
tablespace ROSTER_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table roster.T_YCO_CON_PROP
  add primary key (ID)
  using index 
  tablespace ROSTER_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table T_YCO_CON_PROP_DETAIL

prompt
create table roster.T_YCO_CON_PROP_DETAIL
(
  id           NUMBER(19) not null,
  created_by   VARCHAR2(20 CHAR),
  created_date TIMESTAMP(6),
  updated_by   VARCHAR2(20 CHAR),
  updated_date TIMESTAMP(6),
  version      NUMBER(19),
  con_prop_id  NUMBER(19) not null,
  yc_prop_id   NUMBER(19) not null
)
tablespace ROSTER_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table roster.T_YCO_CON_PROP_DETAIL
  add primary key (ID)
  using index 
  tablespace ROSTER_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table T_YCO_CON_SCALE
prompt 
prompt
create table roster.T_YCO_CON_SCALE
(
  id            NUMBER(19) not null,
  created_by    VARCHAR2(20 CHAR),
  created_date  TIMESTAMP(6),
  updated_by    VARCHAR2(20 CHAR),
  updated_date  TIMESTAMP(6),
  version       NUMBER(19),
  contractor_id NUMBER(19) not null,
  ms_count      NUMBER(19) not null,
  ps_count      NUMBER(19) not null,
  remark        VARCHAR2(20 CHAR),
  status        VARCHAR2(1 CHAR) not null
)
tablespace ROSTER_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table roster.T_YCO_CON_SCALE
  add primary key (ID)
  using index 
  tablespace ROSTER_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table T_YCO_CON_SCALE_DETAIL

prompt
create table roster.T_YCO_CON_SCALE_DETAIL
(
  id           NUMBER(19) not null,
  created_by   VARCHAR2(20 CHAR),
  created_date TIMESTAMP(6),
  updated_by   VARCHAR2(20 CHAR),
  updated_date TIMESTAMP(6),
  version      NUMBER(19),
  con_scale_id NUMBER(19) not null,
  end_time     VARCHAR2(5 CHAR),
  shift        VARCHAR2(10 CHAR) not null,
  start_time   VARCHAR2(5 CHAR)
)
tablespace ROSTER_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table roster.T_YCO_CON_SCALE_DETAIL
  add primary key (ID)
  using index 
  tablespace ROSTER_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table T_YCO_CON_YCNO
prompt 
prompt
create table roster.T_YCO_CON_YCNO
(
  id            NUMBER(19) not null,
  created_by    VARCHAR2(20 CHAR),
  created_date  TIMESTAMP(6),
  updated_by    VARCHAR2(20 CHAR),
  updated_date  TIMESTAMP(6),
  version       NUMBER(19),
  contractor_id NUMBER(19) not null,
  remark        VARCHAR2(20 CHAR),
  status        VARCHAR2(1 CHAR) not null
)
tablespace ROSTER_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table roster.T_YCO_CON_YCNO
  add primary key (ID)
  using index 
  tablespace ROSTER_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table T_YCO_CON_YCNO_DETAIL

prompt
create table roster.T_YCO_CON_YCNO_DETAIL
(
  id           NUMBER(19) not null,
  created_by   VARCHAR2(20 CHAR),
  created_date TIMESTAMP(6),
  updated_by   VARCHAR2(20 CHAR),
  updated_date TIMESTAMP(6),
  version      NUMBER(19),
  con_ycno_id  NUMBER(19) not null,
  yc_no_id     NUMBER(19) not null
)
tablespace ROSTER_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table roster.T_YCO_CON_YCNO_DETAIL
  add primary key (ID)
  using index 
  tablespace ROSTER_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table T_YCO_CON_ZONE
prompt 
prompt
create table roster.T_YCO_CON_ZONE
(
  id            NUMBER(19) not null,
  created_by    VARCHAR2(20 CHAR),
  created_date  TIMESTAMP(6),
  updated_by    VARCHAR2(20 CHAR),
  updated_date  TIMESTAMP(6),
  version       NUMBER(19),
  contractor_id NUMBER(19) not null,
  remark        VARCHAR2(20 CHAR),
  status        VARCHAR2(1 CHAR) not null
)
tablespace ROSTER_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table roster.T_YCO_CON_ZONE
  add primary key (ID)
  using index 
  tablespace ROSTER_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table T_YCO_CON_ZONE_DETAIL

prompt
create table roster.T_YCO_CON_ZONE_DETAIL
(
  id           NUMBER(19) not null,
  created_by   VARCHAR2(20 CHAR),
  created_date TIMESTAMP(6),
  updated_by   VARCHAR2(20 CHAR),
  updated_date TIMESTAMP(6),
  version      NUMBER(19),
  con_zone_id  NUMBER(19) not null,
  priority     NUMBER(10) not null,
  yc_zone_id   NUMBER(19) not null
)
tablespace ROSTER_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table roster.T_YCO_CON_ZONE_DETAIL
  add primary key (ID)
  using index 
  tablespace ROSTER_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table T_YCO_MS_BASE_INFO
prompt 
prompt
create table roster.T_YCO_MS_BASE_INFO
(
  id           NUMBER(19) not null,
  created_by   VARCHAR2(20 CHAR),
  created_date TIMESTAMP(6),
  updated_by   VARCHAR2(20 CHAR),
  updated_date TIMESTAMP(6),
  version      NUMBER(19),
  remark       VARCHAR2(500 CHAR),
  shift        VARCHAR2(10 CHAR) not null,
  shift_date   DATE not null,
  yc_ref       VARCHAR2(500 CHAR)
)
tablespace ROSTER_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table roster.T_YCO_MS_BASE_INFO
  add primary key (ID)
  using index 
  tablespace ROSTER_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
create index roster.UIDX_YCO_MS_SHIFT on roster.T_YCO_MS_BASE_INFO (SHIFT_DATE, SHIFT)
  tablespace ROSTER_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table T_YCO_MS_OP_CL_YC_SNAPSHOT

prompt
create table roster.T_YCO_MS_OP_CL_YC_SNAPSHOT
(
  id              NUMBER(19) not null,
  created_by      VARCHAR2(20 CHAR),
  created_date    TIMESTAMP(6),
  updated_by      VARCHAR2(20 CHAR),
  updated_date    TIMESTAMP(6),
  version         NUMBER(19),
  open_close_type VARCHAR2(40 CHAR),
  shift           VARCHAR2(10 CHAR) not null,
  shift_date      DATE not null,
  yc_no           VARCHAR2(8 CHAR),
  yc_zone         VARCHAR2(20 CHAR)
)
tablespace ROSTER_DATA
  pctfree 10
  initrans 1
  maxtrans 255;
alter table roster.T_YCO_MS_OP_CL_YC_SNAPSHOT
  add primary key (ID)
  using index 
  tablespace ROSTER_DATA
  pctfree 10
  initrans 2
  maxtrans 255;
create index roster.IDX_YCO_MS_OCY_SHIFT on roster.T_YCO_MS_OP_CL_YC_SNAPSHOT (SHIFT_DATE, SHIFT)
  tablespace ROSTER_DATA
  pctfree 10
  initrans 2
  maxtrans 255;

prompt
prompt Creating table T_YCO_MS_SHIFT_OPEN_CLOSE_YC

prompt
create table roster.T_YCO_MS_SHIFT_OPEN_CLOSE_YC
(
  id                 NUMBER(19) not null,
  created_by         VARCHAR2(20 CHAR),
  created_date       TIMESTAMP(6),
  updated_by         VARCHAR2(20 CHAR),
  updated_date       TIMESTAMP(6),
  version            NUMBER(19),
  open_close_type    VARCHAR2(40 CHAR),
  shift              VARCHAR2(10 CHAR) not null,
  shift_date         DATE not null,
  yc_new_work_status VARCHAR2(20 CHAR),
  yc_no              VARCHAR2(8 CHAR),
  yc_old_work_status VARCHAR2(20 CHAR),
  yc_zone            VARCHAR2(20 CHAR)
)
tablespace ROSTER_DATA
  pctfree 10
  initrans 1
  maxtrans 255;
alter table roster.T_YCO_MS_SHIFT_OPEN_CLOSE_YC
  add primary key (ID)
  using index 
  tablespace ROSTER_DATA
  pctfree 10
  initrans 2
  maxtrans 255;
create index roster.IDX_YCO_MS_SHIFT_OPEN_CLOSE_YC on roster.T_YCO_MS_SHIFT_OPEN_CLOSE_YC (SHIFT_DATE, SHIFT)
  tablespace ROSTER_DATA
  pctfree 10
  initrans 2
  maxtrans 255;

prompt
prompt Creating table T_YCO_MS_YC_SNAPSHOT

prompt
create table roster.T_YCO_MS_YC_SNAPSHOT
(
  id           NUMBER(19) not null,
  created_by   VARCHAR2(20 CHAR),
  created_date TIMESTAMP(6),
  updated_by   VARCHAR2(20 CHAR),
  updated_date TIMESTAMP(6),
  version      NUMBER(19),
  shift        VARCHAR2(10 CHAR) not null,
  shift_date   DATE not null,
  yc_no        VARCHAR2(8 CHAR) not null,
  yc_status    VARCHAR2(20 CHAR) not null,
  yc_zone      VARCHAR2(20 CHAR) not null
)
tablespace ROSTER_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table roster.T_YCO_MS_YC_SNAPSHOT
  add primary key (ID)
  using index 
  tablespace ROSTER_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
create index roster.UIDX_YCO_YS_SHIFT on roster.T_YCO_MS_YC_SNAPSHOT (SHIFT_DATE, SHIFT, YC_NO)
  tablespace ROSTER_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table T_YCO_MS_YC_STATUS_CHG

prompt
create table roster.T_YCO_MS_YC_STATUS_CHG
(
  id             NUMBER(19) not null,
  created_by     VARCHAR2(20 CHAR),
  created_date   TIMESTAMP(6),
  updated_by     VARCHAR2(20 CHAR),
  updated_date   TIMESTAMP(6),
  version        NUMBER(19),
  effective_date TIMESTAMP(6),
  new_yc_status  VARCHAR2(20 CHAR),
  old_yc_status  VARCHAR2(20 CHAR),
  remark         VARCHAR2(30 CHAR),
  status         VARCHAR2(1 CHAR),
  yc_no          VARCHAR2(8 CHAR)
)
tablespace ROSTER_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table roster.T_YCO_MS_YC_STATUS_CHG
  add primary key (ID)
  using index 
  tablespace ROSTER_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
create index roster.IDX_YCO_YSC_CREATE_DATE on roster.T_YCO_MS_YC_STATUS_CHG (CREATED_DATE)
  tablespace ROSTER_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
create index roster.IDX_YCO_YSC_EFFECTIVE_DATE on roster.T_YCO_MS_YC_STATUS_CHG (EFFECTIVE_DATE)
  tablespace ROSTER_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table T_YCO_MS_YC_STATUS_SNAPSHOT

prompt
create table roster.T_YCO_MS_YC_STATUS_SNAPSHOT
(
  id           NUMBER(19) not null,
  created_by   VARCHAR2(20 CHAR),
  created_date TIMESTAMP(6),
  updated_by   VARCHAR2(20 CHAR),
  updated_date TIMESTAMP(6),
  version      NUMBER(19),
  shift        VARCHAR2(10 CHAR) not null,
  shift_date   DATE not null,
  yc_status    VARCHAR2(20 CHAR) not null
)
tablespace ROSTER_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table roster.T_YCO_MS_YC_STATUS_SNAPSHOT
  add primary key (ID)
  using index 
  tablespace ROSTER_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
create index roster.UIDX_YCO_YCS_SHIFT on roster.T_YCO_MS_YC_STATUS_SNAPSHOT (SHIFT_DATE, SHIFT)
  tablespace ROSTER_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table T_YCO_MS_YC_ZONE_SNAPSHOT

prompt
create table roster.T_YCO_MS_YC_ZONE_SNAPSHOT
(
  id           NUMBER(19) not null,
  created_by   VARCHAR2(20 CHAR),
  created_date TIMESTAMP(6),
  updated_by   VARCHAR2(20 CHAR),
  updated_date TIMESTAMP(6),
  version      NUMBER(19),
  shift        VARCHAR2(10 CHAR) not null,
  shift_date   DATE not null,
  yc_zone      VARCHAR2(20 CHAR) not null
)
tablespace ROSTER_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table roster.T_YCO_MS_YC_ZONE_SNAPSHOT
  add primary key (ID)
  using index 
  tablespace ROSTER_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
create index roster.UIDX_YCO_YZS_YC_ZONE on roster.T_YCO_MS_YC_ZONE_SNAPSHOT (SHIFT_DATE, SHIFT, YC_ZONE)
  tablespace ROSTER_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table T_YCO_ROSTER_ARRANGE_RULE

prompt
create table roster.T_YCO_ROSTER_ARRANGE_RULE
(
  id                      NUMBER(19) not null,
  created_by              VARCHAR2(20 CHAR),
  created_date            TIMESTAMP(6),
  updated_by              VARCHAR2(20 CHAR),
  updated_date            TIMESTAMP(6),
  version                 NUMBER(19),
  assign_ratio_force_rule VARCHAR2(1 CHAR),
  new_open_yc_priority    VARCHAR2(1 CHAR),
  packed_priority         VARCHAR2(1 CHAR),
  relax_period_priority   VARCHAR2(1 CHAR),
  wait_work_priority      VARCHAR2(1 CHAR),
  work_status_priority    VARCHAR2(1 CHAR),
  yc_mfrs_force_rule      VARCHAR2(1 CHAR),
  yc_no_force_rule        VARCHAR2(1 CHAR),
  yc_no_priority          VARCHAR2(1 CHAR),
  yc_prop_force_rule      VARCHAR2(1 CHAR),
  yc_type_priority        VARCHAR2(1 CHAR),
  yc_zone_priority        VARCHAR2(1 CHAR)
)
tablespace ROSTER_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table roster.T_YCO_ROSTER_ARRANGE_RULE
  add primary key (ID)
  using index 
  tablespace ROSTER_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table T_YCO_ROSTER_SHIFT_PLAN_PATH

prompt
create table roster.T_YCO_ROSTER_SHIFT_PLAN_PATH
(
  id            NUMBER(19),
  created_by    VARCHAR2(20 CHAR),
  created_date  TIMESTAMP(6),
  updated_by    VARCHAR2(20 CHAR),
  updated_date  TIMESTAMP(6),
  version       NUMBER(19),
  business_unit VARCHAR2(30 CHAR),
  department    VARCHAR2(30 CHAR),
  group_id      VARCHAR2(20 CHAR),
  section       VARCHAR2(20 CHAR),
  user_id       VARCHAR2(10 CHAR)
)
tablespace ROSTER_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table T_YCO_TEACHER
prompt 
prompt
create table roster.T_YCO_TEACHER
(
  id           NUMBER(19) not null,
  created_by   VARCHAR2(20 CHAR),
  created_date TIMESTAMP(6),
  updated_by   VARCHAR2(20 CHAR),
  updated_date TIMESTAMP(6),
  version      NUMBER(19),
  name         VARCHAR2(60 CHAR),
  age          NUMBER(19),
  join_date    TIMESTAMP(6),
  gender       VARCHAR2(2 CHAR),
  course       VARCHAR2(60 CHAR),
  remark       VARCHAR2(200 CHAR)
)
tablespace ROSTER_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
comment on column roster.T_YCO_TEACHER.name
  is '��ʦ����';
comment on column roster.T_YCO_TEACHER.age
  is '����';
comment on column roster.T_YCO_TEACHER.join_date
  is '��ҵʱ��';
comment on column roster.T_YCO_TEACHER.gender
  is '�Ա�';
comment on column roster.T_YCO_TEACHER.course
  is '���̿γ�';
comment on column roster.T_YCO_TEACHER.remark
  is '��ע';
alter table roster.T_YCO_TEACHER
  add primary key (ID)
  using index 
  tablespace ROSTER_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table T_YCO_YC_BASE_INFO
prompt 
prompt
create table roster.T_YCO_YC_BASE_INFO
(
  id           NUMBER(19) not null,
  created_by   VARCHAR2(20 CHAR),
  created_date TIMESTAMP(6),
  updated_by   VARCHAR2(20 CHAR),
  updated_date TIMESTAMP(6),
  version      NUMBER(19),
  special_yc   CHAR(1 CHAR) not null,
  remark       VARCHAR2(20 CHAR),
  status       VARCHAR2(1 CHAR) not null,
  yc_mfrs_id   NUMBER(19) not null,
  yc_no        VARCHAR2(8 CHAR) not null,
  yc_prop_id   NUMBER(19) not null,
  yc_type_id   NUMBER(19) not null,
  yc_zone_id   NUMBER(19) not null
)
tablespace ROSTER_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table roster.T_YCO_YC_BASE_INFO
  add primary key (ID)
  using index 
  tablespace ROSTER_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table T_YCO_YC_MFRS
prompt 
prompt
create table roster.T_YCO_YC_MFRS
(
  id           NUMBER(19) not null,
  created_by   VARCHAR2(20 CHAR),
  created_date TIMESTAMP(6),
  updated_by   VARCHAR2(20 CHAR),
  updated_date TIMESTAMP(6),
  version      NUMBER(19),
  descr        VARCHAR2(30 CHAR),
  mfrs         VARCHAR2(20 CHAR) not null,
  status       VARCHAR2(1 CHAR) not null
)
tablespace ROSTER_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table roster.T_YCO_YC_MFRS
  add primary key (ID)
  using index 
  tablespace ROSTER_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table T_YCO_YC_PROP
prompt 
prompt
create table roster.T_YCO_YC_PROP
(
  id           NUMBER(19) not null,
  created_by   VARCHAR2(20 CHAR),
  created_date TIMESTAMP(6),
  updated_by   VARCHAR2(20 CHAR),
  updated_date TIMESTAMP(6),
  version      NUMBER(19),
  descr        VARCHAR2(30 CHAR),
  prop         VARCHAR2(10 CHAR) not null,
  status       VARCHAR2(1 CHAR) not null
)
tablespace ROSTER_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table roster.T_YCO_YC_PROP
  add primary key (ID)
  using index 
  tablespace ROSTER_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table T_YCO_YC_REF
prompt 
prompt
create table roster.T_YCO_YC_REF
(
  id             NUMBER(19) not null,
  created_by     VARCHAR2(20 CHAR),
  created_date   TIMESTAMP(6),
  updated_by     VARCHAR2(20 CHAR),
  updated_date   TIMESTAMP(6),
  version        NUMBER(19),
  descr          VARCHAR2(30 CHAR),
  effective_date TIMESTAMP(6) not null,
  ref            VARCHAR2(500 CHAR) not null,
  status         VARCHAR2(1 CHAR) not null
)
tablespace ROSTER_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table roster.T_YCO_YC_REF
  add primary key (ID)
  using index 
  tablespace ROSTER_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table T_YCO_YC_TYPE
prompt 
prompt
create table roster.T_YCO_YC_TYPE
(
  id           NUMBER(19) not null,
  created_by   VARCHAR2(20 CHAR),
  created_date TIMESTAMP(6),
  updated_by   VARCHAR2(20 CHAR),
  updated_date TIMESTAMP(6),
  version      NUMBER(19),
  descr        VARCHAR2(30 CHAR),
  priority     NUMBER(10) not null,
  status       VARCHAR2(1 CHAR) not null,
  type         VARCHAR2(20 CHAR) not null
)
tablespace ROSTER_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table roster.T_YCO_YC_TYPE
  add primary key (ID)
  using index 
  tablespace ROSTER_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table T_YCO_YC_WORK_STATUS

prompt
create table roster.T_YCO_YC_WORK_STATUS
(
  id             NUMBER(19) not null,
  created_by     VARCHAR2(20 CHAR),
  created_date   TIMESTAMP(6),
  updated_by     VARCHAR2(20 CHAR),
  updated_date   TIMESTAMP(6),
  version        NUMBER(19),
  descr          VARCHAR2(30 CHAR),
  is_enroll_plan CHAR(1 CHAR) not null,
  priority       NUMBER(10) not null,
  status         VARCHAR2(1 CHAR) not null,
  work_status    VARCHAR2(20 CHAR) not null
)
tablespace ROSTER_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table roster.T_YCO_YC_WORK_STATUS
  add primary key (ID)
  using index 
  tablespace ROSTER_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table T_YCO_YC_ZONE
prompt 
prompt
create table roster.T_YCO_YC_ZONE
(
  id           NUMBER(19) not null,
  created_by   VARCHAR2(20 CHAR),
  created_date TIMESTAMP(6),
  updated_by   VARCHAR2(20 CHAR),
  updated_date TIMESTAMP(6),
  version      NUMBER(19),
  descr        VARCHAR2(30 CHAR),
  status       VARCHAR2(1 CHAR) not null,
  zone         VARCHAR2(20 CHAR) not null
)
tablespace ROSTER_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table roster.T_YCO_YC_ZONE
  add primary key (ID)
  using index 
  tablespace ROSTER_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table T_YCO_ZONE_ASSIGNED_YC

prompt
create table roster.T_YCO_ZONE_ASSIGNED_YC
(
  id           NUMBER(19) not null,
  created_by   VARCHAR2(20 CHAR),
  created_date TIMESTAMP(6),
  updated_by   VARCHAR2(20 CHAR),
  updated_date TIMESTAMP(6),
  version      NUMBER(19),
  count        NUMBER(10),
  shift        VARCHAR2(10 CHAR) not null,
  shift_date   DATE not null,
  zone         VARCHAR2(20 CHAR)
)
tablespace ROSTER_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table roster.T_YCO_ZONE_ASSIGNED_YC
  add primary key (ID)
  using index 
  tablespace ROSTER_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
create index roster.IDX_YCO_ZONE_ASSIGNED_YC on roster.T_YCO_ZONE_ASSIGNED_YC (SHIFT_DATE, SHIFT)
  tablespace ROSTER_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating view V_ROSTER_ACTUAL_SHIFT_ACTION

prompt
create or replace view roster.v_roster_actual_shift_action as
select "ID",
       "DB_VERSION_STAMP",
       "UPDATE_BY_ACTOR",
       "LAST_UPDATE_TIME",
       "STAFF_ID",
       "STAFF_NAME",
       "BUSINESS_UNIT",
       "DEPARTMENT",
       "SECTION",
       "GROUP_ID",
       "TEAM",
       "TEAM_SEQUENCE",
       "SHIFT_PLAN_DATE",
       "SHIFT_PLAN_ACTION",
       "FIRST_PLAN_ACTION",
       "SHIFT_PLAN_ACTION_STATUS",
       "IS_MANPOWER",
       "OT_TYPE",
       "OT_HOURS",
       "REMARK",
       "CHANGE_REASON",
       "MANUAL_MODIFY",
       "POSITION",
       "IS_TRAINING",
       "SHIFT_CONTENT",
       "SQUAD"
  from rst_actual_shift_action;

prompt
prompt Creating view V_ROSTER_BASIC_SHIFT_PLAN

prompt
create or replace view roster.v_roster_basic_shift_plan as
select "ID",
       "DB_VERSION_STAMP",
       "UPDATE_BY_ACTOR",
       "LAST_UPDATE_TIME",
       "STAFF_ID",
       "STAFF_NAME",
       "BUSINESS_UNIT",
       "DEPARTMENT",
       "SECTION",
       "GROUP_ID",
       "TEAM",
       "TEAM_SEQUENCE",
       "SHIFT_PLAN_DATE",
       "SHIFT_PLAN_ACTION",
       "TEMP_PLAN_ACTION",
       "TEMP_PLAN_ACTION_STATUS",
       "TEMP_PLAN_REMARK",
       "IS_TEMP_PLAN_CONFIRMED",
       "FIRST_PLAN_ACTION",
       "SHIFT_PLAN_ACTION_STATUS",
       "IS_MANPOWER",
       "REMARK",
       "CHANGE_REASON",
       "MANUAL_MODIFY",
       "POSITION",
       "IS_TRAINING",
       "SHIFT_CONTENT",
       "SQUAD"
  from rst_basic_shift_plan;

prompt
prompt Creating view V_ROSTER_HOLIDAY_TYPE

prompt
create or replace view roster.v_roster_holiday_type as
select "ID",
       "DB_VERSION_STAMP",
       "UPDATE_BY_ACTOR",
       "LAST_UPDATE_TIME",
       "SHORT_HOLIDAY_TYPE_NAME",
       "HOLIDAY_TYPE_NAME",
       "HOLIDAY_TYPE_ENGLISH_NAME",
       "IS_SPECIAL",
       "IS_ACTIVE",
       "IS_INCLUDE",
       "IS_CALLOT"
  from rst_holiday_type
 where is_active  'Y';

prompt
prompt Creating view V_ROSTER_STAFF_INFO
prompt 
prompt
create or replace view roster.v_roster_staff_info as
select user_id staffNo,
       password,
       chinese_name staffName,
       english_name staffNameEn,
       email_address emailAddress,
       business_unit businessUnit,
       department,
       section,
       role_code roleName,
       data_access_level dataAccessLevel,
       is_active active
  from rst_secu_user t
 where t.is_active  'Y';

prompt
prompt Creating view V_ROSTER_STAFF_PERMISSIONS

prompt
create or replace view roster.v_roster_staff_permissions as
select permission_code, u.user_id
  from rst_secu_role_access t,
       rst_secu_user        u
 where t.role_code  u.role_code
  and u.is_active  'Y';

prompt
prompt Creating view V_ROSTER_TEAMS
prompt

prompt
create or replace view roster.v_roster_teams as
select "ID",
       "DB_VERSION_STAMP",
       "UPDATE_BY_ACTOR",
       "LAST_UPDATE_TIME",
       "BUSINESS_UNIT",
       "DEPARTMENT",
       "SECTION",
       "GROUP_ID",
       "TEAM",
       "REMARK",
       "IS_ACTIVE",
       "SQUAD"
  from rst_teams;

prompt
prompt Creating view V_ROSTER_USER_DATA_PERMISSION

prompt
create or replace view roster.v_roster_user_data_permission as
select "ID",
       "DB_VERSION_STAMP",
       "UPDATE_BY_ACTOR",
       "LAST_UPDATE_TIME",
       "USER_ID",
       "BUSINESS_UNIT",
       "DEPARTMENT",
       "SECTION",
       "GROUP_ID"
  from rst_secu_user_access_data;


spool off
