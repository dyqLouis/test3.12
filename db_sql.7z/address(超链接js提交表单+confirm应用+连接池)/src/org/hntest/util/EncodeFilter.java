package org.hntest.util;

import java.io.IOException;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;

public class EncodeFilter extends HttpServlet implements Filter {
	private String encode = "UTF-8";
	
	/**
	 * ��ʼ�����������
	 */
	@Override
	public void init(FilterConfig config) throws ServletException {
		   String str = config.getInitParameter("encode");
		   if(str !=null && !"".equals(str)){
			   encode = str;
		   }

	}
	
	/**
	 *  ��Ϊ��servlet�����׳�ServletException���漰���������������Ҫ�ǵ��׳�IOException�쳣
	 */
	@Override
	public void doFilter(ServletRequest arg0, ServletResponse arg1,
			FilterChain arg2) throws IOException, ServletException {
		
		/*//���ֻ����post�Ļ����´���
		arg0.setCharacterEncoding(encode);
		//�����󽻳�
		arg2.doFilter(arg0, arg1);*/
		
		//���post��get�����ǵĻ����´���
		HttpServletRequest  request = (HttpServletRequest )arg0;
		if("POST".equalsIgnoreCase(request.getMethod())){    //���Ϊpost����
			request.setCharacterEncoding(encode);
		}else{
			Map map = request.getParameterMap();
			Set set = map.keySet();
			Iterator it = set.iterator();
			while(it.hasNext()){
				Object obj = map.get(it.next());
				if(obj instanceof String[]){
					String[] values = (String[])obj;
					for(int i=0;i<values.length;i++){
						values[i] = new String(values[i].getBytes("ISO-8859-1"),encode);
					}
				}else{
					String value = (String)obj;
					value = new String(value.getBytes("ISO-8859-1"),encode);
				}
			}
		}
		//�����󽻳�
		arg2.doFilter(arg0, arg1);
	}


	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}


}
