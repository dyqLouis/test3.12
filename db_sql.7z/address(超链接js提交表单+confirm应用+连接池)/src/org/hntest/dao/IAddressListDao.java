package org.hntest.dao;

import org.hntest.bean.AddressList;
import org.hntest.bean.AddressUsers;
import java.sql.SQLException;
import java.util.List;

/**
 * ͨѶ¼���ݷ��ʽӿ�
 * @author Administrator
 *
 */
public interface IAddressListDao {
	public void addAddressList(AddressList addressList) throws  Exception;
	public void delAddressListByides(String[] ides) throws  Exception;
	public void updateAddressList(AddressList addressList) throws  Exception;
	public AddressList findAddressListById(int id) throws  Exception;
	public  List findAddressListByUserId(int userId) throws  Exception;
}
