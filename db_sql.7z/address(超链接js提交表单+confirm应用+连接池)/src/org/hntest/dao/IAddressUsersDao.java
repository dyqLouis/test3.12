package org.hntest.dao;

import org.hntest.bean.AddressUsers;
import java.sql.SQLException;

/**
 * �û������ݷ��ʽӿ�
 * @author Administrator
 *
 */
public interface IAddressUsersDao {
	public  AddressUsers findAddressUsersByProperties(AddressUsers user) throws  Exception;
}
