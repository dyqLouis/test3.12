package org.hntest.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

/**
 * �������ݿ�Ĺ�����
 * @author Administrator
 *
 */
public class BaseDao {
	protected Connection conn = null;
	protected PreparedStatement pst= null;
	protected ResultSet rs = null ;

	/**
	 * ��ȡ����(ͨ�����ӳ�)
	 * @return
	 * @throws Exception
	 */
	public Connection openConn() throws Exception{

		Context context;
		try {
			context = new InitialContext();
			DataSource ds =  (DataSource)context.lookup("java:/comp/env/jdbc/address");
			conn = ds.getConnection();
		} catch (NamingException e) {
			e.printStackTrace();
		}
		return conn;
	}

	/**
	 * �ر������ݿ������
	 * @param conn
	 * @param pst
	 * @param rs
	 */
	public void closeConn(Connection conn, PreparedStatement pst,ResultSet rs){
		try{
			if(rs != null) rs.close();
			if(pst != null) pst.close();
			if(conn != null) conn.close();
		}catch(SQLException e){
			e.printStackTrace();
		}
	}

}
