package org.hntest.dao.impl;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.hntest.bean.AddressList;
import org.hntest.dao.BaseDao;
import org.hntest.dao.IAddressListDao;

/**
 * ͨѶ¼�����ݷ���ʵ����
 * @author Administrator
 *
 */
public class AddressListDao extends BaseDao implements IAddressListDao {

	/**
	 * ������ϵ��
	 */
	public void addAddressList(AddressList addressList) throws Exception {

		String sql = "insert into address_list(userid,name,sex,phone,email,zipCode,address) values(?,?,?,?,?,?,?)";
		try {
			pst = openConn().prepareStatement(sql);
			pst.setInt(1, addressList.getUserid());
			pst.setString(2, addressList.getName());
			pst.setString(3, addressList.getSex());
			pst.setString(4, addressList.getPhone());
			pst.setString(5, addressList.getEmail());
			pst.setString(6, addressList.getZipCode());
			pst.setString(7, addressList.getAddress());
			pst.executeUpdate();
		} catch (Exception e) {
			throw e;
		} finally {
			closeConn(conn, pst, null);
		}
	}

	/**
	 * ����idɾ����ϵ��
	 */
	public void delAddressListByides(String[] ides) throws Exception {
		String sql = "delete from address_list where id in(";
		StringBuffer str = new StringBuffer();
		for (String id : ides) {
			str.append(id).append(",");
		}
		sql = sql +str.subSequence(0, str.length()-1)+")";
		try{
			pst = openConn().prepareStatement(sql);
			pst.executeUpdate();
		}catch (Exception e) {
			throw e;
		} finally {
			closeConn(conn, pst, null);
		}
	}

	/**
	 * �޸���ϵ��
	 */
	public void updateAddressList(AddressList addressList) throws Exception {
		String sql = "update address_list set name=?,sex=?,phone=?,email=?,zipcode=?,address=? where id=?";
		try {
			pst = openConn().prepareStatement(sql);
			pst.setString(1, addressList.getName());
			pst.setString(2, addressList.getSex());
			pst.setString(3, addressList.getPhone());
			pst.setString(4, addressList.getEmail());
			pst.setString(5, addressList.getZipCode());
			pst.setString(6, addressList.getAddress());
			pst.setInt(7, addressList.getId());
			pst.executeUpdate();
		} catch (Exception e) {
			throw e;
		} finally {
			closeConn(conn, pst, null);
		}
	}

	/**
	 * ����id��ѯĳ����ϵ�˵���ϸ��Ϣ
	 */
	public AddressList findAddressListById(int id) throws Exception {
		AddressList addressList = null;
		String sql = "select * from address_list where id=?";
		try {
			pst = openConn().prepareStatement(sql);
			pst.setInt(1, id);
			rs = pst.executeQuery();
			while(rs.next()){
				addressList = new AddressList();
				addressList.setId(rs.getInt(1));
				addressList.setUserid(rs.getInt(2));
				addressList.setName(rs.getString(3));
				addressList.setSex(rs.getString(4));
				addressList.setPhone(rs.getString(5));
				addressList.setEmail(rs.getString(6));
				addressList.setZipCode(rs.getString(7));
				addressList.setAddress(rs.getString(8));
			}
			
		} catch (Exception e) {
			throw e;
		} finally {
			closeConn(conn, pst, null);
		}
		return addressList;
	}

	/**
	 * ����userid��ѯ��ǰ�û���������ϵ��
	 */
	public List findAddressListByUserId(int userId) throws Exception {
		List list = null;
		String sql = "select * from address_list where userId=?";
		try {
			pst = openConn().prepareStatement(sql);
			pst.setInt(1, userId);
			rs = pst.executeQuery();
			list = new ArrayList(100);
			while(rs.next()){
				AddressList addressList = new AddressList();
				addressList.setId(rs.getInt(1));
				addressList.setUserid(rs.getInt(2));
				addressList.setName(rs.getString(3));
				addressList.setSex(rs.getString(4));
				addressList.setPhone(rs.getString(5));
				addressList.setEmail(rs.getString(6));
				addressList.setZipCode(rs.getString(7));
				addressList.setAddress(rs.getString(8));
				list.add(addressList);
			}
		} catch (Exception e) {
			throw e;
		} finally {
			closeConn(conn, pst, null);
		}
		
		return list;
	}
}
