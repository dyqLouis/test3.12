package org.hntest.dao.impl;

import org.hntest.bean.AddressUsers;
import org.hntest.dao.BaseDao;
import org.hntest.dao.IAddressUsersDao;

/**
 * �û����ݷ���ʵ����
 * @author Administrator
 *
 */
public class AddressUsersDao extends BaseDao implements IAddressUsersDao {

	@Override
	public AddressUsers findAddressUsersByProperties(AddressUsers user)
			throws Exception {
		AddressUsers user1 = null;
		String sql = "select * from address_users where userName=? and passWord=?";
		try{
			pst = openConn().prepareStatement(sql);
			pst.setString(1, user.getUserName());
			pst.setString(2, user.getPassWord());
			rs = pst.executeQuery();
			while(rs.next()){
				user1 = new AddressUsers();
				user1.setId(rs.getInt(1));
				user1.setUserName(rs.getString(2));
				user1.setPassWord(rs.getString(3));
			}
		}catch(Exception e){
			throw e;
		}finally{
			closeConn(conn, pst, rs);
		}
		return user1;
	}

}
