package org.hntest.service;

import org.hntest.bean.AddressUsers;
/**
 * �û���ҵ���߼��ӿ�
 * @author Administrator
 *
 */
public interface IAddressUsersService {
	public  AddressUsers findAddressUsersByProperties(AddressUsers user) throws  Exception;

}
