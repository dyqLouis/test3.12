package org.hntest.service;

import java.util.List;

import org.hntest.bean.AddressList;
/**
 * ͨѶ¼��ҵ���߼��ӿ�
 * @author Administrator
 *
 */
public interface IAddressListService {
	public void addAddressList(AddressList addressList) throws  Exception;
	public void delAddressListByides(String[] ides) throws  Exception;
	public void updateAddressList(AddressList addressList) throws  Exception;
	public AddressList findAddressListById(int id) throws  Exception;
	public  List findAddressListByUserId(int userId) throws  Exception;
}
