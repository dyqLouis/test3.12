package org.hntest.service.impl;

import java.util.List;

import org.hntest.bean.AddressList;
import org.hntest.dao.IAddressListDao;
import org.hntest.dao.impl.AddressListDao;
import org.hntest.service.IAddressListService;

/**
 * ͨѶ¼��ҵ���߼�ʵ����
 * @author Administrator
 *
 */
public class IAddressListServImpl implements IAddressListService {
	IAddressListDao dao = new AddressListDao();
	@Override
	public void addAddressList(AddressList addressList) throws Exception {
		  dao.addAddressList(addressList);
	}

	@Override
	public void delAddressListByides(String[] ides) throws Exception {
			dao.delAddressListByides(ides);
	}

	@Override
	public void updateAddressList(AddressList addressList) throws Exception {
			dao.updateAddressList(addressList);
	}

	@Override
	public AddressList findAddressListById(int id) throws Exception {
		return dao.findAddressListById(id);
	}

	@Override
	public List findAddressListByUserId(int userId) throws Exception {
		return dao.findAddressListByUserId(userId);
	}

}
