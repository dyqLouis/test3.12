package org.hntest.service.impl;

import org.hntest.bean.AddressUsers;
import org.hntest.dao.IAddressUsersDao;
import org.hntest.dao.impl.AddressUsersDao;
import org.hntest.service.IAddressUsersService;
/**
 * �û���ҵ���߼�ʵ����
 * @author Administrator
 *
 */
public class IAddressUsersServImpl implements IAddressUsersService {
	 private IAddressUsersDao dao = new AddressUsersDao();

	@Override
	public AddressUsers findAddressUsersByProperties(AddressUsers user)
			throws Exception {
		return dao.findAddressUsersByProperties(user);
	}

}
