package org.hntest.action;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.hntest.bean.AddressUsers;
import org.hntest.service.IAddressUsersService;
import org.hntest.service.impl.IAddressUsersServImpl;

public class LoginAction extends HttpServlet {

	private static final Logger LOG = Logger.getLogger(LoginAction.class);
	
	public LoginAction() {
		super();
	}

	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
        
		// ȡֵ
		String userName = request.getParameter("userName").trim();
		String password = request.getParameter("passWord").trim();
		
		// ��װ��bean����
		AddressUsers user = new AddressUsers();
		user.setUserName(userName);
		user.setPassWord(password);
		
		// ����ҵ���߼���
		IAddressUsersService biz = new IAddressUsersServImpl();
		String url = "login.jsp";
		try {
			LOG.info("��ʼ��¼");
			AddressUsers user1 = biz.findAddressUsersByProperties(user);
			if(user1 != null){
				LOG.info("��¼�ɹ�����½���û�Ϊ"+user1.getUserName());
				request.getSession().setAttribute("user", user1);
				url = "selectAddressListAction";    //ȥ�б���ѯ����
			}else{
				request.setAttribute("loginError", "�û������������") ;
			}
		} catch (Exception e) {
			LOG.error(e);
		}
		// ����ת��
		request.getRequestDispatcher(url).forward(request, response);
	}

	/**
	 * Initialization of the servlet. <br>
	 * 
	 * @throws ServletException
	 *             if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}

}
