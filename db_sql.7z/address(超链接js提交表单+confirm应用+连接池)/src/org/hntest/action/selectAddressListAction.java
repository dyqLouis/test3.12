package org.hntest.action;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.hntest.bean.AddressList;
import org.hntest.bean.AddressUsers;
import org.hntest.service.IAddressListService;
import org.hntest.service.IAddressUsersService;
import org.hntest.service.impl.IAddressListServImpl;

public class selectAddressListAction extends HttpServlet {

	private static final Logger LOG = Logger.getLogger(LoginAction.class);

	public selectAddressListAction() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy();  
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// �õ���ǰ�û�
		AddressUsers user = (AddressUsers)request.getSession().getAttribute("user");
		
		// ����ҵ���߼���(��������ϵ���г���)
		IAddressListService biz = new IAddressListServImpl();
		try {
			LOG.info("��ʼ��ѯ��ǰ�û���ͨѶ¼");
			List list = biz.findAddressListByUserId(user.getId());
			request.setAttribute("addressList", list);
			LOG.info("��ѯ��ǰ�û���ͨѶ¼�ɹ�");
		} catch (Exception e) {
			LOG.error(e);
		}
		
		// ����ת��
		String url = "list.jsp";
		request.getRequestDispatcher(url).forward(request, response);
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		this.doPost(request, response);
	}
	
	public void init() throws ServletException {
		// Put your code here
	}

}
