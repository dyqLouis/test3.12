package org.hntest.action;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.hntest.bean.AddressList;
import org.hntest.bean.AddressUsers;
import org.hntest.service.IAddressListService;
import org.hntest.service.impl.IAddressListServImpl;

public class AddressListAction extends HttpServlet {

	private static final Logger LOG = Logger.getLogger(AddressListAction.class);
	private IAddressListService biz = new IAddressListServImpl();

	/**
	 * Constructor of the object.
	 */
	public AddressListAction() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 * 
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request
	 *            the request send by the client to the server
	 * @param response
	 *            the response send by the server to the client
	 * @throws ServletException
	 *             if an error occurred
	 * @throws IOException
	 *             if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request, response);
	}

	/**
	 * The doPost method of the servlet. <br>
	 * 
	 * ��Ϊ��servlet�����׳�ServletException���漰���������������Ҫ�ǵ��׳�IOException�쳣
	 * post.
	 * 
	 * @param request
	 *            the request send by the client to the server
	 * @param response
	 *            the response send by the server to the client
	 * @throws ServletException
	 *             if an error occurred
	 * @throws IOException
	 *             if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {   

		// ֻ��һ���£��з�����������Ӧ������
		String method = request.getParameter("method");
		if ("add".equals(method)) {
			addAddressList(request, response);
		} else if ("delByIdes".equals(method)) {
			delAddressListByides(request, response);
		} else if ("update".equals(method)) {
			updateAddressList(request, response);
		} else if ("findById".equals(method)) {
			findAddressListById(request, response);
		}

	}

	private void findAddressListById(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		int id = Integer.parseInt(request.getParameter("id"));
		try {
			LOG.info("����id��ѯͨѶ¼��ָ����ϵ����Ϣ");
			AddressList addressList = biz.findAddressListById(id);
			request.setAttribute("personInfo", addressList);
			LOG.info("����id��ѯͨѶ¼��ָ����ϵ����Ϣ�ɹ���");
		} catch (NumberFormatException e) {
			LOG.error("ͨѶ¼id���ݴ���", e);
		} catch (Exception e) {
			LOG.error("����id��ѯͨѶ¼����", e);
		}
		// ����ת�����༭ҳ
		request.getRequestDispatcher("editAddress.jsp").forward(request,
				response);

	}

	private void updateAddressList(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		
		// ȡֵ
		int id = Integer.parseInt(request.getParameter("id"));
		String orignalName = new String(request.getParameter("orignalName"));
		String name = request.getParameter("name");
		String sex = request.getParameter("sex");
		String phone = request.getParameter("phone");
		String email = request.getParameter("email");
		String zipCode = request.getParameter("zipCode");
		String address = request.getParameter("address");

		// ��װ ��bean����
		AddressList addressList = new AddressList();
		addressList.setId(id);
		addressList.setName(name);
		addressList.setSex(sex);
		addressList.setPhone(phone);
		addressList.setEmail(email);
		addressList.setZipCode(zipCode);
		addressList.setAddress(address);

		// ����ҵ���߼�
		try {
			LOG.info("��ʼ�޸�ͨѶ¼��ϵ��\""+orignalName+"\"������");
			biz.updateAddressList(addressList);
			LOG.info("ͨѶ¼��ϵ�˵������޸ĳɹ�");
		} catch (Exception e) {
			LOG.error("ͨѶ¼��ϵ�������޸�ʧ��",e);
		}
		// ����ת��
		String url = "selectAddressListAction";
		request.getRequestDispatcher(url).forward(request, response);

	}

	private void delAddressListByides(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		
		String[] ides =  request.getParameterValues("id");
		try{
			LOG.info("��ʼɾ��ͨѶ¼��ϵ��");
			biz.delAddressListByides(ides);
			LOG.info("ͨѶ¼��ϵ��ɾ���ɹ�");
		}catch(Exception e){
			LOG.error("ͨѶ¼��ϵ��ɾ��ʧ��", e);
		}
		request.getRequestDispatcher("selectAddressListAction").forward(request, response);

	}

	private void addAddressList(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		// ȡֵ
		String name = request.getParameter("name");
		String sex = request.getParameter("sex");
		String phone = request.getParameter("phone");
		String email = request.getParameter("email");
		String zipCode = request.getParameter("zipCode");
		String address = request.getParameter("address");

		// ��װ ��bean����
		AddressUsers user = (AddressUsers) request.getSession().getAttribute("user");
		AddressList addressList = new AddressList();
		addressList.setUserid(user.getId());
		addressList.setName(name);
		addressList.setSex(sex);
		addressList.setPhone(phone);
		addressList.setEmail(email);
		addressList.setZipCode(zipCode);
		addressList.setAddress(address);

		// ����ҵ���߼�
		try {
			LOG.info("��ʼ����ͨѶ¼");
			biz.addAddressList(addressList);
			LOG.info("����ͨѶ¼�ɹ�");
		} catch (Exception e) {
			LOG.error(e);
		}
		// ����ת��
		String url = "selectAddressListAction";
		request.getRequestDispatcher(url).forward(request, response);
	}

	/**
	 * Initialization of the servlet. <br>
	 * 
	 * @throws ServletException
	 *             if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}

}
