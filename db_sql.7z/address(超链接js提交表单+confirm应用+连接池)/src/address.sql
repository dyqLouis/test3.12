use master ;
go
create database address;
go
use address ;
go
CREATE TABLE address_users (
	id int IDENTITY (1, 1) NOT NULL primary key,
	userName varchar (50) NOT NULL unique,
	passWord varchar (50) NOT NULL 
) ;
go
insert into address_users(userName,passWord) values('orion','orion');
insert into address_users(userName,passWord) values('jacky','jacky');
go
CREATE TABLE address_list (
	id int IDENTITY(1, 1) NOT NULL ,
	userid int NOT NULL , --�û�ID
	[name] varchar(50)  NOT NULL unique,
	sex varchar(50)  NOT NULL,
	phone varchar(50) NOT NULL ,
	email varchar(50) NOT NULL ,
	zipCode varchar(50) NOT NULL ,
	address varchar(50) NOT NULL 
);
go
insert into address_list(userid,[name],sex,phone,email,zipCode,address) values(1,'����','��','15200729611','648962167@qq.com','424200','���ϳ�������');  ---orion
insert into address_list(userid,[name],sex,phone,email,zipCode,address) values(1,'����','��','15245345017','648945757@qq.com','424200','���ϳ�������');  ---orion
insert into address_list(userid,[name],sex,phone,email,zipCode,address) values(1,'����','Ů','15245300117','648965557@qq.com','424200','���ϳ�������');  ---orion
--delete from address_list where id=1 ;
--delete from address_list where id in(1,2,3) ;

insert into address_list(userid,[name],sex,phone,email,zipCode,address) values(2,'����','��','15800728611','5896214768@qq.com','424200','���ϳ������');   ---jacky
insert into address_list(userid,[name],sex,phone,email,zipCode,address) values(2,'����','��','15211469471','5842214768@qq.com','424200','���Ϻ�������');   ---jacky


-------oracle��--------------
connect sys/sys123@orcl as sysdba;
grant connect,resource to address identified by address123456;
connect address/address123456@orcl;


create sequence seq_address_users start with 1 increment by 1;  
create sequence seq_address_list start with 1 increment by 1; 

CREATE TABLE address_users (
	"id" int primary key not null,
	userName varchar (50) NOT NULL unique,
	"passWord" varchar (50) NOT NULL 
);

insert into address_users values(1,'orion','orion');
insert into address_users values(seq_address_users.NEXTVAL,'jacky','jacky');
commit;
 
CREATE TABLE address_list (
	"id" int primary key not null ,
	userid int NOT NULL , --�û�ID
	"name" varchar(50)  NOT NULL unique,
	sex varchar(50)  NOT NULL,
	phone varchar(50) NOT NULL ,
	email varchar(50) NOT NULL ,
	zipCode varchar(50) NOT NULL ,
	address varchar(50) NOT NULL 
);

 ---orion
insert into address_list values(1,1,'����','��','15200729611','648962167@qq.com','424200','���ϳ�������'); 
insert into address_list values(seq_address_list.NEXTVAL,1,'����','��','15245345017','648945757@qq.com','424200','���ϳ�������');  
insert into address_list values(seq_address_list.NEXTVAL,1,'����','Ů','15245300117','648965557@qq.com','424200','���ϳ�������');  
--delete from address_list where id=1 ;
--delete from address_list where id in(1,2,3) ; ---��truncate

---jacky
insert into address_list values(seq_address_list.NEXTVAL,2,'����','��','15800728611','5896214768@qq.com','424200','���ϳ������');  
insert into address_list values(seq_address_list.NEXTVAL,2,'����','��','15211469471','5842214768@qq.com','424200','���Ϻ�������'); 
commit;