conn sys/sys123@orcl as sysdba ;

declare num number;   
begin  
 select count(1) into num from all_users where username='TSJPA';  
 if num>0   
  then execute immediate 'drop user TSJPA cascade';   
 end if;   
end;   
/  

grant connect,resource to TSJPA identified by a123456; 
create tablespace TSJPA_DATA logging datafile 'E:\oracle11g\oradata\TSJPA.dbf' size 20M 
autoextend on next 5m maxsize 100m extent management local;

alter user TSJPA default tablespace TSJPA_DATA;

connect TSJPA/a123456@orcl ;

create table t_tsjpa_dictionary
(
  ID           number(19) not null,
  CREATED_BY   varchar2(20 CHAR),
  CREATED_DATE timestamp(6),
  UPDATED_BY   varchar2(20 CHAR),
  UPDATED_DATE timestamp(6),
  VERSION      number(19),
  CATEGORY     varchar2(100 CHAR),
  TEXT         varchar2(200 CHAR),
  VALUE        varchar2(800 CHAR),
  SORT         number(10)
);

alter table t_tsjpa_dictionary  add primary key (ID);

create table t_tsjpa_teacher
(
  id           number(19) not null,
  created_by   varchar2(20 CHAR),
  created_date timestamp(6),
  updated_by   varchar2(20 CHAR),
  updated_date timestamp(6),
  version      number(19),
  name         varchar2(60 CHAR),
  age          number(19),
  join_date    timestamp(6),
  gender       varchar2(2 CHAR),
  course       varchar2(60 CHAR),
  remark       varchar2(200 CHAR)
)
;
comment on column t_tsjpa_teacher.name
  is '��ʦ����';
comment on column t_tsjpa_teacher.age
  is '����';
comment on column t_tsjpa_teacher.join_date
  is '��ҵʱ��';
comment on column t_tsjpa_teacher.gender
  is '�Ա�';
comment on column t_tsjpa_teacher.course
  is '���̿γ�';
comment on column t_tsjpa_teacher.remark
  is '��ע';
alter table t_tsjpa_teacher  add primary key (ID);

prompt Creating t_tsjpa_student...
create table t_tsjpa_student
(
  id           number(19) not null,
  created_by   varchar2(20 CHAR),
  created_date timestamp(6),
  updated_by   varchar2(20 CHAR),
  updated_date timestamp(6),
  version      number(19),
  age          number(10),
  classname    varchar2(60 CHAR),
  gender       varchar2(2 CHAR),
  name         varchar2(40 CHAR),
  remark       varchar2(200 CHAR),
  stuid        number(19),
  teacherid    number(19)
)
;
alter table t_tsjpa_student  add primary key (ID);
alter table t_tsjpa_student  add constraint FK2D04D756517DD21C foreign key (teacherid)
  references t_tsjpa_teacher (ID);

prompt Loading t_tsjpa_dictionary...
insert into t_tsjpa_dictionary (ID, CREATED_BY, CREATED_DATE, UPDATED_BY, UPDATED_DATE, VERSION, CATEGORY, TEXT, VALUE, SORT)
values (31, 'admin', to_timestamp('14-07-2014 09:45:54.000000', 'dd-mm-yyyy hh24:mi:ss.ff'), null, null, 0, 'STUDENYT_GENDER', '��', 'M', 0);
insert into t_tsjpa_dictionary (ID, CREATED_BY, CREATED_DATE, UPDATED_BY, UPDATED_DATE, VERSION, CATEGORY, TEXT, VALUE, SORT)
values (32, 'admin', to_timestamp('27-05-2014 14:32:34.000000', 'dd-mm-yyyy hh24:mi:ss.ff'), null, null, 0, 'STUDENYT_GENDER', 'Ů', 'F', 1);
insert into t_tsjpa_dictionary (ID, CREATED_BY, CREATED_DATE, UPDATED_BY, UPDATED_DATE, VERSION, CATEGORY, TEXT, VALUE, SORT)
values (29, 'admin', to_timestamp('27-05-2014 14:32:34.000000', 'dd-mm-yyyy hh24:mi:ss.ff'), null, null, 0, 'TEACHER_GENDER', '��', 'M', 0);
insert into t_tsjpa_dictionary (ID, CREATED_BY, CREATED_DATE, UPDATED_BY, UPDATED_DATE, VERSION, CATEGORY, TEXT, VALUE, SORT)
values (30, 'admin', to_timestamp('27-05-2014 14:32:34.000000', 'dd-mm-yyyy hh24:mi:ss.ff'), null, null, 0, 'TEACHER_GENDER', 'Ů', 'F', 1);
commit;

prompt Disabling triggers for t_tsjpa_teacher...
alter table t_tsjpa_teacher disable all triggers;
prompt Disabling triggers for t_tsjpa_student...
alter table t_tsjpa_student disable all triggers;
prompt Loading t_tsjpa_teacher...
insert into t_tsjpa_teacher (id, created_by, created_date, updated_by, updated_date, version, name, age, join_date, gender, course, remark)
values (101, 'job', to_timestamp('28-10-2014 09:49:21.329000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'job', to_timestamp('07-11-2014 09:13:53.321000', 'dd-mm-yyyy hh24:mi:ss.ff'), 2, '����', 44, to_timestamp('15-04-2014 00:00:00.000000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'F', 'E��', '��E�ε���ʦ');
insert into t_tsjpa_teacher (id, created_by, created_date, updated_by, updated_date, version, name, age, join_date, gender, course, remark)
values (23, 'job', to_timestamp('26-10-2014 11:44:07.196000', 'dd-mm-yyyy hh24:mi:ss.ff'), null, null, 0, '����ʦ', 30, to_timestamp('15-04-2014 00:00:00.000000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'F', 'E��', '��E�ε���ʦ');
insert into t_tsjpa_teacher (id, created_by, created_date, updated_by, updated_date, version, name, age, join_date, gender, course, remark)
values (21, 'job', to_timestamp('25-10-2014 21:49:56.077000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'job', to_timestamp('26-11-2014 23:17:49.273000', 'dd-mm-yyyy hh24:mi:ss.ff'), 1, '����ʦ', 31, to_timestamp('25-10-2014 00:00:00.000000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'F', 'A��', '��A�ε���ʦ');
insert into t_tsjpa_teacher (id, created_by, created_date, updated_by, updated_date, version, name, age, join_date, gender, course, remark)
values (22, 'job', to_timestamp('26-10-2014 11:39:28.234000', 'dd-mm-yyyy hh24:mi:ss.ff'), null, null, 0, '����ʦ', 31, to_timestamp('15-04-2014 00:00:00.000000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'F', 'D��', '��D�ε���ʦ');
insert into t_tsjpa_teacher (id, created_by, created_date, updated_by, updated_date, version, name, age, join_date, gender, course, remark)
values (24, 'job', to_timestamp('25-10-2014 21:49:56.077000', 'dd-mm-yyyy hh24:mi:ss.ff'), null, null, 0, '����2', 31, to_timestamp('25-10-2014 00:00:00.000000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'M', '����ʮ����', '��˵ˮ��ѵĵ���');
insert into t_tsjpa_teacher (id, created_by, created_date, updated_by, updated_date, version, name, age, join_date, gender, course, remark)
values (25, 'job', to_timestamp('25-10-2014 21:49:56.077000', 'dd-mm-yyyy hh24:mi:ss.ff'), null, null, 0, '��ʦa', 31, to_timestamp('25-01-2014 00:00:00.000000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'M', 'ʿ������ط�', '��ʿ������ط�');
insert into t_tsjpa_teacher (id, created_by, created_date, updated_by, updated_date, version, name, age, join_date, gender, course, remark)
values (26, 'job', to_timestamp('25-10-2014 21:49:56.077000', 'dd-mm-yyyy hh24:mi:ss.ff'), null, null, 0, '��ʦb', 25, to_timestamp('25-01-2014 00:00:00.000000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'F', 'dddf', '��dddf');
insert into t_tsjpa_teacher (id, created_by, created_date, updated_by, updated_date, version, name, age, join_date, gender, course, remark)
values (30, 'job', to_timestamp('25-10-2014 21:49:56.077000', 'dd-mm-yyyy hh24:mi:ss.ff'), null, null, 0, 'ŷ����', 49, to_timestamp('25-02-2014 00:00:00.000000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'M', 'fff', '��fff');
insert into t_tsjpa_teacher (id, created_by, created_date, updated_by, updated_date, version, name, age, join_date, gender, course, remark)
values (31, 'job', to_timestamp('25-10-2014 21:49:56.077000', 'dd-mm-yyyy hh24:mi:ss.ff'), null, null, 0, '����а', 49, to_timestamp('25-02-2014 00:00:00.000000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'M', 'jjjjj', '��jjjjj');
insert into t_tsjpa_teacher (id, created_by, created_date, updated_by, updated_date, version, name, age, join_date, gender, course, remark)
values (8, 'job', to_timestamp('23-10-2014 01:27:45.756000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'job', to_timestamp('26-10-2014 15:56:50.768000', 'dd-mm-yyyy hh24:mi:ss.ff'), 6, '����ʦ', 31, to_timestamp('25-10-2014 00:00:00.000000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'F', 'A��', '��A�ε���ʦ');
insert into t_tsjpa_teacher (id, created_by, created_date, updated_by, updated_date, version, name, age, join_date, gender, course, remark)
values (108, 'admin', to_timestamp('23-10-2014 09:31:02.106000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'job', to_timestamp('28-10-2014 14:09:53.447000', 'dd-mm-yyyy hh24:mi:ss.ff'), 3, '��ʦ1', 41, to_timestamp('02-10-2014 00:00:00.000000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'M', '�γ�', 'sdfsaf');
commit;
prompt 11 records loaded
prompt Loading t_tsjpa_student
insert into t_tsjpa_student (id, created_by, created_date, updated_by, updated_date, version, age, classname, gender, name, remark, stuid, teacherid)
values (81, 'job', to_timestamp('28-10-2014 09:49:21.329000', 'dd-mm-yyyy hh24:mi:ss.ff'), null, null, 1, 34, null, 'M', 'Louis1', null, 10013, 101);
insert into t_tsjpa_student (id, created_by, created_date, updated_by, updated_date, version, age, classname, gender, name, remark, stuid, teacherid)
values (82, 'job', to_timestamp('28-10-2014 09:49:21.329000', 'dd-mm-yyyy hh24:mi:ss.ff'), null, null, 1, 12, null, 'F', 'Louis2', null, 10014, 101);
insert into t_tsjpa_student (id, created_by, created_date, updated_by, updated_date, version, age, classname, gender, name, remark, stuid, teacherid)
values (44, 'job', to_timestamp('26-10-2014 11:39:28.234000', 'dd-mm-yyyy hh24:mi:ss.ff'), null, null, 0, 13, null, 'F', '������', null, 10009, 22);
insert into t_tsjpa_student (id, created_by, created_date, updated_by, updated_date, version, age, classname, gender, name, remark, stuid, teacherid)
values (45, 'job', to_timestamp('26-10-2014 11:39:28.234000', 'dd-mm-yyyy hh24:mi:ss.ff'), null, null, 0, 14, null, 'M', '�����', null, 10010, 22);
insert into t_tsjpa_student (id, created_by, created_date, updated_by, updated_date, version, age, classname, gender, name, remark, stuid, teacherid)
values (46, 'job', to_timestamp('26-10-2014 11:44:07.196000', 'dd-mm-yyyy hh24:mi:ss.ff'), null, null, 0, 15, null, 'F', '����', null, 10011, 23);
insert into t_tsjpa_student (id, created_by, created_date, updated_by, updated_date, version, age, classname, gender, name, remark, stuid, teacherid)
values (47, 'job', to_timestamp('26-10-2014 11:44:07.196000', 'dd-mm-yyyy hh24:mi:ss.ff'), null, null, 0, 16, null, 'M', '���˽�', null, 10012, 23);
insert into t_tsjpa_student (id, created_by, created_date, updated_by, updated_date, version, age, classname, gender, name, remark, stuid, teacherid)
values (41, 'job', to_timestamp('25-10-2014 19:09:16.206000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'job', to_timestamp('26-10-2014 15:56:50.768000', 'dd-mm-yyyy hh24:mi:ss.ff'), 1, 17, null, 'M', 'ɳɮ', null, 10003, 8);
insert into t_tsjpa_student (id, created_by, created_date, updated_by, updated_date, version, age, classname, gender, name, remark, stuid, teacherid)
values (25, 'job', to_timestamp('23-10-2014 01:27:45.756000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'job', to_timestamp('26-10-2014 15:56:50.768000', 'dd-mm-yyyy hh24:mi:ss.ff'), 4, 31, null, 'M', '�Ž�', null, 10002, 8);
insert into t_tsjpa_student (id, created_by, created_date, updated_by, updated_date, version, age, classname, gender, name, remark, stuid, teacherid)
values (26, 'job', to_timestamp('23-10-2014 01:27:45.756000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'job', to_timestamp('26-10-2014 15:56:50.768000', 'dd-mm-yyyy hh24:mi:ss.ff'), 4, 25, null, 'F', '������', null, 10006, 8);
insert into t_tsjpa_student (id, created_by, created_date, updated_by, updated_date, version, age, classname, gender, name, remark, stuid, teacherid)
values (32, 'job', to_timestamp('23-10-2014 01:36:04.295000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'job', to_timestamp('26-10-2014 15:56:50.768000', 'dd-mm-yyyy hh24:mi:ss.ff'), 3, 22, null, 'M', '��ɮ', null, 10001, 8);
insert into t_tsjpa_student (id, created_by, created_date, updated_by, updated_date, version, age, classname, gender, name, remark, stuid, teacherid)
values (48, 'job', to_timestamp('26-10-2014 12:39:29.808000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'job', to_timestamp('26-10-2014 15:56:50.768000', 'dd-mm-yyyy hh24:mi:ss.ff'), 1, 35, null, 'F', '���', null, 10005, 8);
insert into t_tsjpa_student (id, created_by, created_date, updated_by, updated_date, version, age, classname, gender, name, remark, stuid, teacherid)
values (49, 'job', to_timestamp('26-10-2014 15:56:50.768000', 'dd-mm-yyyy hh24:mi:ss.ff'), null, null, 0, 26, null, 'F', 'ܽ�ؽ��', null, 10004, 8);
commit;